// src/utils/treeLayout.test.js
import { calculateTreeLayout } from './treeLayout';

describe('calculateTreeLayout', () => {
  it('should return an empty array if no data is provided', () => {
    const result = calculateTreeLayout([]);
    expect(result).toEqual([]);
  });

  it('should correctly identify the root node', () => {
    const simpleData = [
      { id: '2', name: 'Child', father_id: '1' },
      { id: '1', name: 'Root', father_id: null },
    ];
    const { nodes } = calculateTreeLayout(simpleData);
    // d3-hierarchy reorders the nodes, so we can't assume nodes[0] is the root.
    const rootNode = nodes.find(n => n.id === '1');
    expect(rootNode.depth).toBe(0);
  });

  it('should correctly position a simple parent-child relationship', () => {
    const simpleData = [
      { id: '1', name: 'Root', father_id: null },
      { id: '2', name: 'Child', father_id: '1' },
    ];
    const { nodes } = calculateTreeLayout(simpleData);
    const rootNode = nodes.find(n => n.id === '1');
    const childNode = nodes.find(n => n.id === '2');

    // The primary assertion: the child node should be positioned below the root node.
    expect(childNode.y).toBeGreaterThan(rootNode.y);
  });
});
