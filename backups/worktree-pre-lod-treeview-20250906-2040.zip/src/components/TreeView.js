import React, { useMemo, useEffect, useState, useCallback, useRef } from 'react';
import {
  View,
  Dimensions,
  useWindowDimensions,
  Platform,
  I18nManager,
  ActivityIndicator,
  Text,
  Alert,
  PixelRatio,
} from 'react-native';
import {
  Canvas,
  Group,
  Rect,
  Line,
  Circle,
  vec,
  RoundedRect,
  useImage,
  Image as SkiaImage,
  Skia,
  Mask,
  Paragraph,
  listFontFamilies,
  Text as SkiaText,
  useFont,
  Path,
} from '@shopify/react-native-skia';
import { GestureDetector, Gesture } from 'react-native-gesture-handler';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withDecay,
  withTiming,
  withSequence,
  withRepeat,
  Easing,
  runOnJS,
  clamp,
  useAnimatedReaction,
  cancelAnimation,
  useDerivedValue,
} from 'react-native-reanimated';
import { familyData } from '../data/family-data';
import { Asset } from 'expo-asset';
import { calculateTreeLayout } from '../utils/treeLayout';
import { useTreeStore } from '../stores/useTreeStore';
import profilesService from '../services/profiles';
import { formatDateDisplay } from '../services/migrationHelpers';
import NavigateToRootButton from './NavigateToRootButton';
import { useAdminMode } from '../contexts/AdminModeContext';
import GlobalFAB from './admin/GlobalFAB';
import SystemStatusIndicator from './admin/SystemStatusIndicator';
import MultiAddChildrenModal from './admin/MultiAddChildrenModal';
import skiaImageCache from '../services/skiaImageCache';
import { useCachedSkiaImage } from '../hooks/useCachedSkiaImage';
import NodeContextMenu from './admin/NodeContextMenu';
import EditProfileScreen from '../screens/EditProfileScreen';
import { supabase } from '../services/supabase';

const VIEWPORT_MARGIN = 800; // Increased to reduce culling jumps on zoom
const NODE_WIDTH_WITH_PHOTO = 85;
const NODE_WIDTH_TEXT_ONLY = 60;
const NODE_HEIGHT_WITH_PHOTO = 90;
const NODE_HEIGHT_TEXT_ONLY = 35;
const PHOTO_SIZE = 60;
const LINE_COLOR = '#BDBDBD';
const LINE_WIDTH = 2;
const CORNER_RADIUS = 8;

// Connection rendering constants - all in pixels, converted to world in hook
const ANCHOR_MAX_PX = 14; // Max pixel thickness for landmark connections
const TRUNK_MIN_PX = 4; // Min pixel thickness for trunk lines at mid zoom
const BUS_GAP_LANDMARK_PX = 50; // Pixel gap below landmark nodes
const BUS_GAP_STANDARD_PX = 20; // Pixel gap below standard nodes
const BUS_SPREAD_MIN_PX = 12; // Min child spread (px) to justify bus line
const CONNECTION_HYSTERESIS = 0.05; // Hysteresis for visibility transitions

// Dynamic LOD settings
const PILL_WIDTH = 60;
const PILL_HEIGHT = 25;
const DOT_SIZE = 16; // Increased from 12 for better visibility

// Scale thresholds for transitions
const DETAIL_THRESHOLD = 0.7; // Scale > this = Full Detail
const STRUCTURE_THRESHOLD = 0.25; // Scale < this = Overview (Dots)
// In between = Structure (Pills)

// Performance Constants
const MAX_VISIBLE_NODES = 350; // Hard cap per frame
const MAX_VISIBLE_EDGES = 200; // Hard cap per frame - reduced for better perf

// Debug flags - set to true to enable specific logging
// To enable: DEBUG_FLAGS.telemetry = true (or any other flag)
// Note: These only work in development mode (__DEV__)
const DEBUG_FLAGS = {
  telemetry: false, // Performance stats (nodes, edges, cache) - logs every 10 seconds
  gestures: false, // Pinch, pan, tap events
  visibility: false, // Node visibility changes
  cache: false, // Image cache operations (requires enabling in skiaImageCache.ts too)
  layout: false, // Tree layout calculations
};

// Image bucket hysteresis constants
const BUCKET_HYSTERESIS = 0.15; // ±15% hysteresis
const BUCKET_DEBOUNCE_MS = 150; // ms

// Create font manager/provider once
let fontMgr = null;
let arabicFontProvider = null;
let arabicTypeface = null;
let arabicFont = null;
let arabicFontBold = null;
let sfArabicRegistered = false;

const SF_ARABIC_ALIAS = 'SF Arabic';
const SF_ARABIC_ASSET = require('../../assets/fonts/SF Arabic Regular.ttf');

try {
  fontMgr = Skia.FontMgr.System();
  arabicFontProvider = Skia.TypefaceFontProvider.Make();

  // List all available fonts to find Arabic fonts
  const availableFonts = listFontFamilies();
  // Try to match Arabic fonts - prioritize SF Arabic
  const arabicFontNames = [
    'SF Arabic', // Prefer SF Arabic explicitly
    '.SF Arabic', // Alternate internal name variants
    '.SF NS Arabic',
    '.SFNSArabic',
    'Geeza Pro',
    'GeezaPro',
    'Damascus',
    'Al Nile',
    'Baghdad',
    '.SF NS Display',
    '.SF NS Text',
    '.SF NS',
    '.SFNS-Regular',
  ];

  for (const fontName of arabicFontNames) {
    try {
      arabicTypeface = fontMgr.matchFamilyStyle(fontName, { weight: 400, width: 5, slant: 0 });
      if (arabicTypeface) {
        // Create Font objects from typeface
        arabicFont = Skia.Font(arabicTypeface, 11);
        const boldTypeface = fontMgr.matchFamilyStyle(fontName, {
          weight: 700,
          width: 5,
          slant: 0,
        });
        arabicFontBold = boldTypeface ? Skia.Font(boldTypeface, 11) : arabicFont;
        break;
      }
    } catch (e) {
      // Continue trying other fonts
    }
  }
} catch (e) {
  // Font collection creation failed
}

// Helper function to create Arabic text paragraphs with proper shaping
const createArabicParagraph = (text, fontWeight, fontSize, color, maxWidth) => {
  if (!text || !Skia.ParagraphBuilder) return null;

  try {
    const paragraphStyle = {
      textAlign: 2, // Center align (0=left, 1=right, 2=center)
      textDirection: 1, // RTL direction (0=LTR, 1=RTL)
      maxLines: 1,
      ellipsis: '...',
    };

    // If we have a matched Arabic typeface, ensure it's registered on the provider
    if (arabicTypeface && arabicFontProvider) {
      try {
        arabicFontProvider.registerFont(arabicTypeface, SF_ARABIC_ALIAS);
      } catch (e) {}
    }

    const textStyle = {
      color: Skia.Color(color),
      fontSize: fontSize,
      fontFamilies: arabicTypeface
        ? [SF_ARABIC_ALIAS]
        : [
            SF_ARABIC_ALIAS,
            '.SF Arabic',
            '.SF NS Arabic',
            '.SFNSArabic',
            'Geeza Pro',
            'GeezaPro',
            'Damascus',
            'Al Nile',
            'Baghdad',
            'System',
          ],
      fontStyle: {
        weight: fontWeight === 'bold' ? 700 : 400,
      },
    };

    // Create paragraph builder
    const builder = arabicFontProvider
      ? Skia.ParagraphBuilder.Make(paragraphStyle, arabicFontProvider)
      : Skia.ParagraphBuilder.Make(paragraphStyle);

    if (!builder) return null;

    builder.pushStyle(textStyle);
    builder.addText(text);

    const paragraph = builder.build();
    if (!paragraph) return null;

    paragraph.layout(maxWidth);

    return paragraph;
  } catch (error) {
    return null;
  }
};

// Image buckets for LOD - reduced to minimize cache duplication
const IMAGE_BUCKETS = [128, 256, 512]; // Removed 64px to reduce cache entries
const selectBucket = pixelSize => {
  return IMAGE_BUCKETS.find(b => b >= pixelSize) || 512;
};

// Image component for photos with skeleton loader
const ImageNode = ({
  url,
  x,
  y,
  width,
  height,
  radius,
  shouldLoad,
  scale,
  nodeId,
  selectBucket,
  opacity = 1,
}) => {
  const pixelSize = width * scale; // screen dp only

  // Use hysteresis bucket selection if provided, otherwise use simple selection
  const bucket = shouldLoad
    ? selectBucket && nodeId
      ? selectBucket(nodeId, pixelSize * 2)
      : IMAGE_BUCKETS.find(b => b >= pixelSize * 2) || 512
    : null;

  const image = shouldLoad ? useCachedSkiaImage(url, bucket) : null;

  // If no image yet, show simple skeleton placeholder
  if (!image) {
    return (
      <Group>
        {/* Base circle background */}
        <Circle cx={x + radius} cy={y + radius} r={radius} color="#F5F5F5" />
        {/* Lighter inner circle for depth */}
        <Circle
          cx={x + radius}
          cy={y + radius}
          r={radius - 1}
          color="#FAFAFA"
          style="stroke"
          strokeWidth={0.5}
        />
      </Group>
    );
  }

  // Image loaded - show it with the mask
  return (
    <Group opacity={opacity}>
      <Mask mode="alpha" mask={<Circle cx={x + radius} cy={y + radius} r={radius} color="white" />}>
        <SkiaImage image={image} x={x} y={y} width={width} height={height} fit="cover" />
      </Mask>
    </Group>
  );
};

// Spatial grid for efficient culling
const GRID_CELL_SIZE = 512;

class SpatialGrid {
  constructor(nodes, cellSize = GRID_CELL_SIZE) {
    this.cellSize = cellSize;
    this.grid = new Map(); // "x,y" -> Set<nodeId>

    // Build grid
    nodes.forEach(node => {
      const cellX = Math.floor(node.x / cellSize);
      const cellY = Math.floor(node.y / cellSize);
      const key = `${cellX},${cellY}`;

      if (!this.grid.has(key)) {
        this.grid.set(key, new Set());
      }
      this.grid.get(key).add(node.id);
    });
  }

  getVisibleNodes({ x, y, width, height }, scale, idToNode) {
    // Transform viewport to world space
    const worldMinX = -x / scale;
    const worldMaxX = (-x + width) / scale;
    const worldMinY = -y / scale;
    const worldMaxY = (-y + height) / scale;

    // Get intersecting cells
    const minCellX = Math.floor(worldMinX / this.cellSize);
    const maxCellX = Math.floor(worldMaxX / this.cellSize);
    const minCellY = Math.floor(worldMinY / this.cellSize);
    const maxCellY = Math.floor(worldMaxY / this.cellSize);

    // Collect nodes from cells
    const visibleIds = new Set();
    for (let cx = minCellX; cx <= maxCellX; cx++) {
      for (let cy = minCellY; cy <= maxCellY; cy++) {
        const cellNodes = this.grid.get(`${cx},${cy}`);
        if (cellNodes) {
          cellNodes.forEach(id => visibleIds.add(id));
        }
      }
    }

    // Convert to nodes and apply hard cap
    const visibleNodes = [];
    for (const id of visibleIds) {
      if (visibleNodes.length >= 1000) break; // Very high limit
      const node = idToNode.get(id);
      if (node) visibleNodes.push(node);
    }

    return visibleNodes;
  }
}

// Pre-calculated connection map hook - single source of truth for all connection lines
const useConnectionSegments = (
  visibleConnections,
  idToNode,
  parentToChildren,
  nodeVisuals,
  scale,
  getNodeImportance,
  culledNodeIds,
  groupVisibilityLatchRef,
) => {
  return useMemo(() => {
    const segments = [];
    const drawnSegments = new Set();
    const groupVisibilityLatch = groupVisibilityLatchRef.current;

    const addSegment = (key, segment) => {
      if (!drawnSegments.has(key)) {
        segments.push(segment);
        drawnSegments.add(key);
      }
    };

    const interpolate = (val, in_s, in_e, out_s, out_e) =>
      clamp(
        out_s + ((val - in_s) / (in_e - in_s)) * (out_e - out_s),
        Math.min(out_s, out_e),
        Math.max(out_s, out_e),
      );

    // Explicit thickness curves with hysteresis
    const pixelThicknessStandard = scale => {
      if (scale >= STRUCTURE_THRESHOLD + CONNECTION_HYSTERESIS) return LINE_WIDTH;
      if (scale <= STRUCTURE_THRESHOLD - CONNECTION_HYSTERESIS) return 0;
      // Smooth interpolation in hysteresis band
      const t =
        (scale - (STRUCTURE_THRESHOLD - CONNECTION_HYSTERESIS)) / (2 * CONNECTION_HYSTERESIS);
      return LINE_WIDTH * t;
    };

    const pixelThicknessTrunk = scale => {
      if (scale >= STRUCTURE_THRESHOLD) return LINE_WIDTH;
      // Smooth growth from TRUNK_MIN_PX to ANCHOR_MAX_PX
      const t = clamp((STRUCTURE_THRESHOLD - scale) / STRUCTURE_THRESHOLD, 0, 1);
      return TRUNK_MIN_PX + (ANCHOR_MAX_PX - TRUNK_MIN_PX) * t;
    };

    // First pass: Calculate unified trunk
    let trunkBusY = null;
    let trunkMinX = Infinity;
    let trunkMaxX = -Infinity;
    const rootNode = [...idToNode.values()].find(n => n.generation === 1);

    if (rootNode) {
      const rootVisuals = nodeVisuals.get(rootNode.id);
      if (rootVisuals) {
        trunkBusY = rootNode.y + rootVisuals.height / 2 + BUS_GAP_LANDMARK_PX / scale;
      }
    }

    // Find hero bounds using getNodeImportance
    for (const node of idToNode.values()) {
      if (getNodeImportance(node) === 0.8) {
        // Heroes
        trunkMinX = Math.min(trunkMinX, node.x);
        trunkMaxX = Math.max(trunkMaxX, node.x);
      }
    }

    // Only create trunk if there are heroes
    const hasTrunk = trunkBusY !== null && trunkMaxX > trunkMinX;

    // Add root trunk vertical ONLY if trunk bus exists
    if (rootNode && hasTrunk) {
      const rootVisuals = nodeVisuals.get(rootNode.id);
      const trunkThickness = pixelThicknessTrunk(scale) / scale;

      if (trunkThickness > 0 && rootVisuals) {
        addSegment('trunk:v:root', {
          type: 'v',
          role: 'trunk',
          layer: 2,
          x: rootNode.x,
          y1: rootNode.y + rootVisuals.height / 2 + trunkThickness / 2,
          y2: trunkBusY - trunkThickness / 2,
          worldThickness: trunkThickness,
        });
      }
    }

    // Add unified trunk bus
    if (hasTrunk) {
      const trunkThickness = pixelThicknessTrunk(scale) / scale;
      if (trunkThickness > 0) {
        addSegment('trunk:h:trunk', {
          type: 'h',
          role: 'trunk',
          layer: 2,
          y: trunkBusY,
          x1: trunkMinX,
          x2: trunkMaxX,
          worldThickness: trunkThickness,
        });
      }
    }

    // Second pass: Process connections
    for (const conn of visibleConnections) {
      const parent = idToNode.get(conn.parent.id);
      if (!parent) continue;

      const parentVisuals = nodeVisuals.get(parent.id);
      if (!parentVisuals) continue;

      const parentImportance = getNodeImportance(parent);
      const isLandmark = parentImportance >= 0.8;
      const isRoot = parent.generation === 1;
      const isHero = parentImportance === 0.8;

      // Get visible children only
      const childNodes = conn.children
        .filter(c => culledNodeIds.has(c.id))
        .map(c => idToNode.get(c.id))
        .filter(Boolean);

      if (childNodes.length === 0) continue;

      // GROUP GATING with persistent hysteresis
      const visibleChildVisuals = childNodes.map(n => nodeVisuals.get(n.id)).filter(Boolean);

      const groupKey = parent.id;
      const prevVisibility = groupVisibilityLatch.get(groupKey) || false;
      const threshold = prevVisibility ? 0.1 - CONNECTION_HYSTERESIS : 0.1 + CONNECTION_HYSTERESIS;
      const hasVisibleGroup = visibleChildVisuals.some(v => v.nameOpacity > threshold);
      groupVisibilityLatch.set(groupKey, hasVisibleGroup);

      if (!hasVisibleGroup) continue; // Skip entire group

      // Calculate bus position
      const busGapPx = isLandmark ? BUS_GAP_LANDMARK_PX : BUS_GAP_STANDARD_PX;
      const busGapWorld = busGapPx / scale;

      // For heroes, use trunk bus; for others, local bus
      const busY =
        isHero && hasTrunk ? trunkBusY : parent.y + parentVisuals.height / 2 + busGapWorld;

      // Parent vertical (skip root, already drawn as trunk)
      if (!isRoot) {
        const parentRole = isLandmark ? 'trunk' : 'standard';
        const parentPixelThickness =
          parentRole === 'trunk' ? pixelThicknessTrunk(scale) : pixelThicknessStandard(scale);
        let parentWorldThickness = parentPixelThickness / scale;

        if (parentWorldThickness > 0) {
          let y1 = parent.y + parentVisuals.height / 2 + parentWorldThickness / 2;
          let y2 = busY - parentWorldThickness / 2;

          // Morph retraction for standard lines
          if (parentRole === 'standard' && parentPixelThickness < LINE_WIDTH) {
            const fadeFactor = parentPixelThickness / LINE_WIDTH;
            const midY = (y1 + y2) / 2;
            y1 = y1 + (midY - y1) * (1 - fadeFactor);
            y2 = y2 + (midY - y2) * (1 - fadeFactor);
          }

          addSegment(`${parentRole}:v:${parent.id}`, {
            type: 'v',
            role: parentRole,
            layer: parentRole === 'trunk' ? 2 : 1,
            x: parent.x,
            y1,
            y2,
            worldThickness: parentWorldThickness,
          });
        }
      }

      // Draw bus ONLY for non-heroes (heroes use trunk bus)
      if (!isHero) {
        const childXs = childNodes.map(n => n.x);
        const minX = Math.min(...childXs);
        const maxX = Math.max(...childXs);
        const spreadPx = (maxX - minX) * scale;

        if ((childNodes.length > 1 || spreadPx > BUS_SPREAD_MIN_PX) && maxX > minX) {
          const busRole = 'standard';
          const busPixelThickness = pixelThicknessStandard(scale);
          const busWorldThickness = busPixelThickness / scale;

          if (busWorldThickness > 0) {
            addSegment(`${busRole}:h:${parent.id}`, {
              type: 'h',
              role: busRole,
              layer: 1,
              y: busY,
              x1: minX,
              x2: maxX,
              worldThickness: busWorldThickness,
            });
          }
        }
      }

      // Child verticals (for all visible children)
      for (const child of childNodes) {
        const childVisuals = nodeVisuals.get(child.id);
        if (!childVisuals) continue;

        const childPixelThickness = pixelThicknessStandard(scale);
        let childWorldThickness = childPixelThickness / scale;

        if (childWorldThickness > 0) {
          let y1 = busY + childWorldThickness / 2;
          let y2 = child.y - childVisuals.height / 2 - childWorldThickness / 2;

          // Morph retraction
          if (childPixelThickness < LINE_WIDTH) {
            const fadeFactor = childPixelThickness / LINE_WIDTH;
            const midY = (y1 + y2) / 2;
            y1 = y1 + (midY - y1) * (1 - fadeFactor);
            y2 = y2 + (midY - y2) * (1 - fadeFactor);
          }

          addSegment(`standard:v:${child.id}`, {
            type: 'v',
            role: 'standard',
            layer: 1,
            x: child.x,
            y1,
            y2,
            worldThickness: childWorldThickness,
          });
        }
      }
    }

    return segments;
  }, [
    visibleConnections,
    idToNode,
    parentToChildren,
    nodeVisuals,
    scale,
    getNodeImportance,
    culledNodeIds,
    groupVisibilityLatchRef,
  ]);
};

const TreeView = ({ setProfileEditMode }) => {
  const stage = useTreeStore(s => s.stage);
  const setStage = useTreeStore(s => s.setStage);
  const minZoom = useTreeStore(s => s.minZoom);
  const maxZoom = useTreeStore(s => s.maxZoom);
  const selectedPersonId = useTreeStore(s => s.selectedPersonId);
  const setSelectedPersonId = useTreeStore(s => s.setSelectedPersonId);
  const treeData = useTreeStore(s => s.treeData);
  const setTreeData = useTreeStore(s => s.setTreeData);

  const dimensions = useWindowDimensions();
  const [fontReady, setFontReady] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [currentScale, setCurrentScale] = useState(1);

  // Admin mode state
  const { isAdminMode } = useAdminMode();
  const [showMultiAddModal, setShowMultiAddModal] = useState(false);
  const [multiAddParent, setMultiAddParent] = useState(null);
  const [showContextMenu, setShowContextMenu] = useState(false);
  const [contextMenuNode, setContextMenuNode] = useState(null);
  const [contextMenuPosition, setContextMenuPosition] = useState({ x: 0, y: 0 });
  const [editingProfile, setEditingProfile] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);

  // Track overview entry for auto-framing
  const [wasInOverview, setWasInOverview] = useState(false);

  // Image bucket tracking for hysteresis
  const nodeBucketsRef = useRef(new Map());
  const bucketTimersRef = useRef(new Map());

  // Persistent group visibility latch for connection rendering
  const groupVisibilityLatchRef = useRef(new Map());

  // Tier 3 chip hitboxes
  const t3ChipBoxesRef = useRef([]);

  // Cleanup bucket timers on unmount
  useEffect(() => {
    return () => {
      bucketTimersRef.current.forEach(clearTimeout);
      bucketTimersRef.current.clear();
    };
  }, []);

  const selectBucketWithHysteresis = useCallback((nodeId, pixelSize) => {
    const nodeBuckets = nodeBucketsRef.current;
    const bucketTimers = bucketTimersRef.current;

    // Default to middle bucket to reduce cache entries
    const current = nodeBuckets.get(nodeId) || 256;
    const target = IMAGE_BUCKETS.find(b => b >= pixelSize) || 512;

    // Increased hysteresis to reduce bucket changes
    const STRICT_HYSTERESIS = 0.3; // 30% threshold instead of 15%

    // Apply stricter hysteresis
    if (target > current && pixelSize < current * (1 + STRICT_HYSTERESIS)) {
      return current; // Stay at current
    }
    if (target < current && pixelSize > current * (1 - STRICT_HYSTERESIS)) {
      return current; // Stay at current
    }

    // Debounce all bucket changes (not just upgrades)
    if (target !== current) {
      // Clear existing timer
      const existingTimer = bucketTimers.get(nodeId);
      if (existingTimer) clearTimeout(existingTimer);

      // Set new timer with longer debounce
      const timer = setTimeout(() => {
        nodeBuckets.set(nodeId, target);
        bucketTimers.delete(nodeId); // Clean up timer reference
      }, 300); // Increased from 150ms to 300ms

      bucketTimers.set(nodeId, timer);
      return current;
    }

    return current;
  }, []);

  // Performance telemetry
  const frameStatsRef = useRef({
    nodesDrawn: 0,
    edgesDrawn: 0,
    lastLogTime: Date.now(),
  });

  // Setup telemetry interval with cleanup - controlled by debug flags
  useEffect(() => {
    if (!__DEV__ || !DEBUG_FLAGS.telemetry) return;

    const interval = setInterval(() => {
      const stats = frameStatsRef.current;
      console.log(
        `📊 Nodes: ${stats.nodesDrawn}/${MAX_VISIBLE_NODES} | ` +
          `Edges: ${stats.edgesDrawn}/${MAX_VISIBLE_EDGES}`,
      );

      if (stats.nodesDrawn >= MAX_VISIBLE_NODES * 0.9) {
        console.warn('⚠️ Approaching node render cap!');
      }
      if (stats.edgesDrawn >= MAX_VISIBLE_EDGES * 0.9) {
        console.warn('⚠️ Approaching edge render cap!');
      }

      // Log cache stats
      const cacheStats = skiaImageCache.getStats();
      console.log(
        `💾 Cache: ${cacheStats.entries} entries | ${cacheStats.totalMB}MB / ${cacheStats.budgetMB}MB (${cacheStats.utilization})`,
      );
    }, 10000); // Changed from 1 second to 10 seconds

    return () => clearInterval(interval);
  }, []);

  // Force RTL for Arabic text
  useEffect(() => {
    I18nManager.forceRTL(true);
  }, []);

  // Create ref to hold current values for gestures
  const gestureStateRef = useRef({
    transform: { x: 0, y: 0, scale: 1 },
    indices: null,
    visibleNodes: [],
  });

  // Load SF Arabic asset font and register with Paragraph font collection
  useEffect(() => {
    if (!arabicFontProvider || sfArabicRegistered) return;
    (async () => {
      try {
        const asset = Asset.fromModule(SF_ARABIC_ASSET);
        if (!asset.downloaded) {
          await asset.downloadAsync();
        }
        const uri = asset.localUri || asset.uri;
        if (!uri) return;
        const data = await Skia.Data.fromURI(uri);
        if (!data) return;
        const tf = Skia.Typeface.MakeFreeTypeFaceFromData(data);
        if (!tf) return;
        arabicFontProvider.registerFont(tf, SF_ARABIC_ALIAS);
        arabicTypeface = tf;
        sfArabicRegistered = true;
        setFontReady(v => !v);
      } catch (e) {
        // Ignore loading errors; fall back to system fonts
      }
    })();
  }, []);

  // Gesture shared values
  const scale = useSharedValue(stage.scale);
  const translateX = useSharedValue(stage.x);
  const translateY = useSharedValue(stage.y);
  const savedScale = useSharedValue(stage.scale);
  const savedTranslateX = useSharedValue(stage.x);
  const savedTranslateY = useSharedValue(stage.y);
  const focalX = useSharedValue(0);
  const focalY = useSharedValue(0);

  // Sync scale value to React state for use in render
  useAnimatedReaction(
    () => scale.value,
    current => {
      runOnJS(setCurrentScale)(current);
    },
  );

  // Load tree data using branch loading
  const loadTreeData = async () => {
    setIsLoading(true);
    try {
      // First get the root node
      const { data: rootData, error: rootError } = await profilesService.getBranchData(null, 1, 1);
      if (rootError || !rootData || rootData.length === 0) {
        console.error('Error loading root node:', rootError);
        // Fall back to local data
        setTreeData(familyData);
        setIsLoading(false);
        return;
      }

      // Then load the tree starting from the root HID
      const rootHid = rootData[0].hid;
      const { data, error } = await profilesService.getBranchData(rootHid, 8, 500);
      if (error) {
        // Fall back to local data
        setTreeData(familyData);
      } else if (data) {
        // console.log('🐞 DEBUG MODE: Tracking zoom/pan issues. Look for:');
        // console.log('  - Node positions changing (they shouldn\'t)');
        // console.log('  - Large visibility changes during zoom');
        // console.log('  - Focal point jumps between pinches');
        setTreeData(data); // Store in zustand for ProfileSheet
      }
    } catch (err) {
      console.error('Failed to load tree data:', err);
      // Fall back to local data
      setLocalTreeData(familyData);
      setTreeData(familyData);
    } finally {
      setIsLoading(false);
    }
  };

  // Load tree data on mount
  useEffect(() => {
    loadTreeData();
  }, [setTreeData]);

  // Real-time subscription for profile updates
  useEffect(() => {
    const channel = supabase
      .channel('profiles_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'profiles',
        },
        async payload => {
          // console.log('Profile change:', payload);

          // Handle different event types
          if (payload.eventType === 'UPDATE' && payload.new) {
            // Update just the affected node
            const updatedNode = {
              ...payload.new,
              name: payload.new.name || 'بدون اسم',
              marriages:
                payload.new.marriages?.map(marriage => ({
                  ...marriage,
                  marriage_date: marriage.marriage_date
                    ? formatDateDisplay(marriage.marriage_date)
                    : null,
                })) || [],
            };

            // Update in Zustand store
            useTreeStore.getState().updateNode(updatedNode.id, updatedNode);
          } else if (payload.eventType === 'INSERT' && payload.new) {
            // Add new node
            const newNode = {
              ...payload.new,
              name: payload.new.name || 'بدون اسم',
              marriages:
                payload.new.marriages?.map(marriage => ({
                  ...marriage,
                  marriage_date: marriage.marriage_date
                    ? formatDateDisplay(marriage.marriage_date)
                    : null,
                })) || [],
            };

            // Add to Zustand store
            useTreeStore.getState().addNode(newNode);
          } else if (payload.eventType === 'DELETE' && payload.old) {
            // Remove node
            const nodeId = payload.old.id;

            // Remove from Zustand store
            useTreeStore.getState().removeNode(nodeId);
          }
        },
      )
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [setTreeData]);

  // Calculate layout
  const { nodes, connections } = useMemo(() => {
    if (isLoading || treeData.length === 0) {
      return { nodes: [], connections: [] };
    }
    const layout = calculateTreeLayout(treeData);

    // DEBUG: Log canvas coordinates summary (these should NEVER change)
    // if (__DEV__ && layout.nodes.length > 0) {
    //   const bounds = layout.nodes.reduce((acc, node) => ({
    //     minX: Math.min(acc.minX, node.x),
    //     maxX: Math.max(acc.maxX, node.x),
    //     minY: Math.min(acc.minY, node.y),
    //     maxY: Math.max(acc.maxY, node.y)
    //   }), { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity });
    //
    //   console.log('🎯 LAYOUT CALCULATED:');
    //   console.log(`  Nodes: ${layout.nodes.length}, Connections: ${layout.connections.length}`);
    //   console.log(`  Bounds: X[${bounds.minX.toFixed(0)}, ${bounds.maxX.toFixed(0)}] Y[${bounds.minY.toFixed(0)}, ${bounds.maxY.toFixed(0)}]`);
    //   console.log(`  Root: ${layout.nodes[0]?.name} at (${layout.nodes[0]?.x.toFixed(0)}, ${layout.nodes[0]?.y.toFixed(0)})`);
    // }

    return layout;
  }, [treeData, isLoading]);

  // Build indices for LOD system with O(N) complexity
  const indices = useMemo(() => {
    if (nodes.length === 0) {
      return {
        idToNode: new Map(),
        parentToChildren: new Map(),
        depths: {},
        subtreeSizes: {},
        centroids: {},
        heroes: new Set(),
        heroNodes: [],
      };
    }

    const idToNode = new Map();
    const parentToChildren = new Map();
    const depths = {};
    const subtreeSizes = {};
    const sumX = {};
    const sumY = {};
    const centroids = {};

    // Build maps - only truthy father_id
    nodes.forEach(node => {
      idToNode.set(node.id, node);
      if (node.father_id) {
        if (!parentToChildren.has(node.father_id)) {
          parentToChildren.set(node.father_id, []);
        }
        parentToChildren.get(node.father_id).push(node);
      }
    });

    // BFS for depths
    const root = nodes.find(n => !n.father_id);
    if (!root) {
      console.error('No root node found!');
      return {
        idToNode,
        parentToChildren,
        depths: {},
        subtreeSizes: {},
        centroids: {},
        heroes: new Set(),
        heroNodes: [],
      };
    }

    const queue = [{ id: root.id, depth: 0 }];
    while (queue.length > 0) {
      const { id, depth } = queue.shift();
      depths[id] = depth;
      const children = parentToChildren.get(id) || [];
      children.forEach(child => queue.push({ id: child.id, depth: depth + 1 }));
    }

    // Iterative post-order for subtree sizes and centroids
    const stack = [root.id];
    const visited = new Set();
    const postOrder = [];

    while (stack.length > 0) {
      const nodeId = stack[stack.length - 1];
      if (!visited.has(nodeId)) {
        visited.add(nodeId);
        const children = parentToChildren.get(nodeId) || [];
        children.forEach(child => stack.push(child.id));
      } else {
        stack.pop();
        postOrder.push(nodeId);
      }
    }

    // Calculate sizes and centroids (no reverse - already in correct order)
    postOrder.forEach(nodeId => {
      const node = idToNode.get(nodeId);
      const children = parentToChildren.get(nodeId) || [];

      // Subtree sizes
      subtreeSizes[nodeId] = 1 + children.reduce((sum, child) => sum + subtreeSizes[child.id], 0);

      // Sum positions for centroid
      sumX[nodeId] = node.x + children.reduce((sum, child) => sum + sumX[child.id], 0);
      sumY[nodeId] = node.y + children.reduce((sum, child) => sum + sumY[child.id], 0);

      // Compute centroid
      centroids[nodeId] = {
        x: sumX[nodeId] / subtreeSizes[nodeId],
        y: sumY[nodeId] / subtreeSizes[nodeId],
      };
    });

    // Select heroes: root + top 2 gen-2 with children (depth === 1)
    const gen2Nodes = nodes.filter(n => depths[n.id] === 1);
    const gen2WithKids = gen2Nodes.filter(n => (parentToChildren.get(n.id) || []).length > 0);
    const heroGen2 = gen2WithKids
      .sort((a, b) => subtreeSizes[b.id] - subtreeSizes[a.id])
      .slice(0, 2);

    return {
      idToNode,
      parentToChildren,
      depths,
      subtreeSizes,
      centroids,
      heroes: new Set([root.id, ...heroGen2.map(n => n.id)]),
      heroNodes: [root, ...heroGen2],
    };
  }, [nodes]);

  // Create spatial grid for efficient culling
  const spatialGrid = useMemo(() => {
    if (nodes.length === 0) return null;
    return new SpatialGrid(nodes);
  }, [nodes]);

  // Calculate tree bounds
  const treeBounds = useMemo(() => {
    if (nodes.length === 0)
      return { minX: 0, maxX: 0, minY: 0, maxY: 0, width: 0, height: 0, centerX: 0, centerY: 0 };

    const xs = nodes.map(n => n.x);
    const ys = nodes.map(n => n.y);

    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys);

    return {
      minX,
      maxX,
      minY,
      maxY,
      width: maxX - minX,
      height: maxY - minY,
      centerX: (minX + maxX) / 2,
      centerY: (minY + maxY) / 2,
    };
  }, [nodes]);

  // Calculate scale that fits the entire tree with padding
  const fitScale = useMemo(() => {
    if (!treeBounds) return 0.15; // fallback
    const pad = 200; // world-space padding
    const w = treeBounds.maxX - treeBounds.minX + 2 * pad;
    const h = treeBounds.maxY - treeBounds.minY + 2 * pad;
    const sx = dimensions.width / w;
    const sy = dimensions.height / h;
    return Math.min(sx, sy);
  }, [treeBounds, dimensions]);

  // Allow zooming slightly smaller than fit if needed
  const localMinZoom = useMemo(() => Math.min(fitScale * 0.9, 0.08), [fitScale]);

  // Helper: zoom to fit the entire tree
  const zoomToFit = useCallback(() => {
    if (!treeBounds) return;
    const targetScale = clamp(fitScale, localMinZoom, maxZoom);
    const cx = (treeBounds.minX + treeBounds.maxX) / 2;
    const cy = (treeBounds.minY + treeBounds.maxY) / 2;
    const tx = dimensions.width / 2 - cx * targetScale;
    const ty = dimensions.height / 2 - cy * targetScale;

    scale.value = withTiming(targetScale, { duration: 400 });
    translateX.value = withTiming(tx, { duration: 400 });
    translateY.value = withTiming(ty, { duration: 400 });

    setTimeout(() => {
      savedScale.value = targetScale;
      savedTranslateX.value = tx;
      savedTranslateY.value = ty;
    }, 420);
  }, [treeBounds, fitScale, localMinZoom, maxZoom, dimensions]);

  // Visible bounds for culling
  const [visibleBounds, setVisibleBounds] = useState({
    minX: -VIEWPORT_MARGIN,
    maxX: dimensions.width + VIEWPORT_MARGIN,
    minY: -VIEWPORT_MARGIN,
    maxY: dimensions.height + VIEWPORT_MARGIN,
  });

  // Track last stable scale to detect significant changes
  const lastStableScale = useRef(1);

  // Update visible bounds when transform changes
  useAnimatedReaction(
    () => ({
      x: translateX.value,
      y: translateY.value,
      scale: scale.value,
    }),
    current => {
      // Scale-dependent margin: larger margin when zoomed out
      const dynamicMargin = VIEWPORT_MARGIN / current.scale;

      const newBounds = {
        minX: (-current.x - dynamicMargin) / current.scale,
        maxX: (-current.x + dimensions.width + dynamicMargin) / current.scale,
        minY: (-current.y - dynamicMargin) / current.scale,
        maxY: (-current.y + dimensions.height + dynamicMargin) / current.scale,
      };

      runOnJS(setVisibleBounds)(newBounds);
    },
  );

  // Load more nodes when viewport changes (for future viewport-based loading)
  useEffect(() => {
    // TODO: Implement viewport-based loading when backend supports it
    // This would call profilesService.getVisibleNodes(visibleBounds, scale.value)
  }, [visibleBounds]);

  // Track previous visible nodes for debugging
  const prevVisibleNodesRef = useRef(new Set());

  // Filter visible nodes for performance
  const visibleNodes = useMemo(() => {
    const startTime = performance.now();

    // Only update visibility if scale changed significantly (>5%)
    const scaleChanged =
      Math.abs(currentScale - lastStableScale.current) / lastStableScale.current > 0.05;
    if (scaleChanged) {
      lastStableScale.current = currentScale;
    }

    const visible = nodes.filter(
      node =>
        node.x >= visibleBounds.minX &&
        node.x <= visibleBounds.maxX &&
        node.y >= visibleBounds.minY &&
        node.y <= visibleBounds.maxY,
    );

    // DEBUG: Track visibility changes
    if (__DEV__) {
      const currentVisibleIds = new Set(visible.map(n => n.id));
      const prevVisibleIds = prevVisibleNodesRef.current;

      // Find nodes that entered/exited view
      const entered = [];
      const exited = [];

      currentVisibleIds.forEach(id => {
        if (!prevVisibleIds.has(id)) {
          const node = visible.find(n => n.id === id);
          entered.push(node);
        }
      });

      prevVisibleIds.forEach(id => {
        if (!currentVisibleIds.has(id)) {
          const node = nodes.find(n => n.id === id);
          if (node) exited.push(node);
        }
      });

      // if (entered.length > 0 || exited.length > 0) {
      //   console.log(`👁️ VISIBILITY: ${prevVisibleIds.size}→${currentVisibleIds.size} nodes | +${entered.length} -${exited.length} | ${(performance.now() - startTime).toFixed(1)}ms`);
      //
      //   // Warn about large visibility changes that might cause jumping
      //   if (entered.length + exited.length > 20) {
      //     console.log(`  ⚠️ LARGE CHANGE: ${entered.length + exited.length} nodes changed visibility!`);
      //     console.log(`  Viewport: X[${visibleBounds.minX.toFixed(0)}, ${visibleBounds.maxX.toFixed(0)}] Y[${visibleBounds.minY.toFixed(0)}, ${visibleBounds.maxY.toFixed(0)}]`);
      //   }
      //
      //   // Only log details if few changes
      //   if (entered.length > 0 && entered.length <= 5) {
      //     console.log(`  Entered: ${entered.map(n => `${n.name}(${n.x.toFixed(0)},${n.y.toFixed(0)})`).join(', ')}`);
      //   }
      //   if (exited.length > 0 && exited.length <= 5) {
      //     console.log(`  Exited: ${exited.map(n => `${n.name}(${n.x.toFixed(0)},${n.y.toFixed(0)})`).join(', ')}`);
      //   }
      // }

      prevVisibleNodesRef.current = currentVisibleIds;
    }

    return visible;
  }, [nodes, visibleBounds, currentScale]);

  // Prefetch neighbor nodes for better performance
  useEffect(() => {
    if (!visibleNodes.length) return;

    // Create a set of visible node IDs for O(1) lookup
    const visibleIds = new Set(visibleNodes.map(n => n.id));
    const neighborUrls = new Set();

    // Find neighbors (parents and children of visible nodes)
    for (const node of visibleNodes) {
      // Add parent
      if (node.father_id) {
        const parent = nodes.find(n => n.id === node.father_id);
        if (parent && !visibleIds.has(parent.id) && parent.photo_url) {
          neighborUrls.add(parent.photo_url);
        }
      }

      // Add children
      const children = nodes.filter(n => n.father_id === node.id);
      for (const child of children) {
        if (!visibleIds.has(child.id) && child.photo_url) {
          neighborUrls.add(child.photo_url);
        }
      }
    }

    // Prefetch up to 6 unique URLs
    const urlsToPreload = Array.from(neighborUrls).slice(0, 6);
    urlsToPreload.forEach(url => {
      skiaImageCache.prefetch(url, 256).catch(() => {
        // Prefetch errors are non-fatal, ignore
      });
    });
  }, [visibleNodes, nodes]);

  // Track previous visible connections for debugging
  const prevVisibleConnectionsRef = useRef(0);

  // Initialize position on first load
  useEffect(() => {
    if (nodes.length > 0 && stage.x === 0 && stage.y === 0 && stage.scale === 1) {
      const offsetX = dimensions.width / 2 - (treeBounds.minX + treeBounds.maxX) / 2;
      const offsetY = 80;

      translateX.value = offsetX;
      translateY.value = offsetY;
      savedTranslateX.value = offsetX;
      savedTranslateY.value = offsetY;

      setStage({ x: offsetX, y: offsetY, scale: 1 });
    }
  }, [nodes, dimensions, treeBounds]);

  // Pan gesture with momentum
  const panGesture = Gesture.Pan()
    .onStart(() => {
      cancelAnimation(translateX);
      cancelAnimation(translateY);
      savedTranslateX.value = translateX.value;
      savedTranslateY.value = translateY.value;
    })
    .onUpdate(e => {
      translateX.value = savedTranslateX.value + e.translationX;
      translateY.value = savedTranslateY.value + e.translationY;
    })
    .onEnd(e => {
      translateX.value = withDecay({
        velocity: e.velocityX,
        deceleration: 0.995,
      });
      translateY.value = withDecay({
        velocity: e.velocityY,
        deceleration: 0.995,
      });

      // Save current values (before decay animation modifies them)
      savedTranslateX.value = translateX.value;
      savedTranslateY.value = translateY.value;
    });

  // Pinch gesture for zoom with pointer-anchored transform
  const pinchGesture = Gesture.Pinch()
    .onStart(e => {
      // CRITICAL: Cancel any running animations to prevent value drift
      cancelAnimation(translateX);
      cancelAnimation(translateY);
      cancelAnimation(scale);

      // Now save the current stable values
      savedScale.value = scale.value;
      savedTranslateX.value = translateX.value;
      savedTranslateY.value = translateY.value;

      // Store initial focal point for stability (rounded to prevent float issues)
      focalX.value = Math.round(e.focalX);
      focalY.value = Math.round(e.focalY);

      // Debug logging
      // if (__DEV__) {
      //   console.log(`🤏 PINCH START: Scale:${scale.value.toFixed(2)} Focal:(${Math.round(e.focalX)},${Math.round(e.focalY)}) Fingers:${e.numberOfPointers}`);
      // }
    })
    .onUpdate(e => {
      const s = clamp(savedScale.value * e.scale, localMinZoom, maxZoom);
      const k = s / savedScale.value;

      // Use initial focal point for stability (prevents drift with repeated pinches)
      const stableFocalX = focalX.value;
      const stableFocalY = focalY.value;

      // Calculate new transform
      const newX = stableFocalX - (stableFocalX - savedTranslateX.value) * k;
      const newY = stableFocalY - (stableFocalY - savedTranslateY.value) * k;

      // Apply transform
      translateX.value = newX;
      translateY.value = newY;
      scale.value = s;

      // DEBUG: Log significant scale changes only
      // if (__DEV__ && Math.abs(e.scale - 1) > 0.1) { // Only log 10%+ changes
      //   console.log(`🔍 ZOOM: ${savedScale.value.toFixed(2)}→${s.toFixed(2)} | Focal:(${stableFocalX.toFixed(0)},${stableFocalY.toFixed(0)}) | Δ:(${(newX - savedTranslateX.value).toFixed(0)},${(newY - savedTranslateY.value).toFixed(0)})`);
      // }
    })
    .onEnd(() => {
      savedScale.value = scale.value;
      savedTranslateX.value = translateX.value;
      savedTranslateY.value = translateY.value;

      // Debug logging
      // if (__DEV__) {
      //   console.log(`✅ PINCH END: Scale:${scale.value.toFixed(2)} Pos:(${translateX.value.toFixed(0)},${translateY.value.toFixed(0)})`);
      // }
    });

  // Tap gesture for selection with movement/time thresholds
  const tapGesture = Gesture.Tap()
    .maxDistance(10)
    .maxDuration(250)
    .runOnJS(true)
    .onEnd(e => {
      const state = gestureStateRef.current;

      // Progressive LOD - check visible nodes
      const canvasX = (e.x - state.transform.x) / state.transform.scale;
      const canvasY = (e.y - state.transform.y) / state.transform.scale;

      // DEBUG: Log tap coordinates
      // if (__DEV__) {
      //   console.log(`👆 TAP: Screen(${e.x.toFixed(0)},${e.y.toFixed(0)}) → Canvas(${canvasX.toFixed(0)},${canvasY.toFixed(0)}) @ Scale:${scale.value.toFixed(2)}`);
      // }

      let tappedNodeId = null;
      for (const node of state.visibleNodes) {
        const nodeWidth = node.photo_url ? NODE_WIDTH_WITH_PHOTO : NODE_WIDTH_TEXT_ONLY;
        const nodeHeight = node.photo_url ? NODE_HEIGHT_WITH_PHOTO : NODE_HEIGHT_TEXT_ONLY;

        if (
          canvasX >= node.x - nodeWidth / 2 &&
          canvasX <= node.x + nodeWidth / 2 &&
          canvasY >= node.y - nodeHeight / 2 &&
          canvasY <= node.y + nodeHeight / 2
        ) {
          tappedNodeId = node.id;

          // DEBUG: Log tapped node
          // if (__DEV__) {
          //   console.log(`  → Hit: ${node.name} at (${node.x.toFixed(0)},${node.y.toFixed(0)})`);
          // }

          break;
        }
      }

      handleNodeTap(tappedNodeId);
    });

  // Handle node tap - show profile sheet (edit mode if admin)
  const handleNodeTap = useCallback(
    nodeId => {
      // console.log('TreeView: Node tapped, isAdminMode:', isAdminMode);
      setSelectedPersonId(nodeId);
      setProfileEditMode(isAdminMode);
      // console.log('TreeView: Setting profileEditMode to:', isAdminMode);
    },
    [setSelectedPersonId, isAdminMode],
  );

  // Handle chip tap in T3 - zoom to branch
  const handleChipTap = useCallback(
    hero => {
      // Calculate bounds of hero's subtree
      const descendantIds = new Set();
      const stack = [hero.id];

      while (stack.length > 0) {
        const nodeId = stack.pop();
        descendantIds.add(nodeId);
        const children = indices.parentToChildren.get(nodeId) || [];
        children.forEach(child => stack.push(child.id));
      }

      // Find bounds of all descendants
      let minX = Infinity,
        maxX = -Infinity,
        minY = Infinity,
        maxY = -Infinity;
      descendantIds.forEach(id => {
        const node = indices.idToNode.get(id);
        if (node) {
          minX = Math.min(minX, node.x);
          maxX = Math.max(maxX, node.x);
          minY = Math.min(minY, node.y);
          maxY = Math.max(maxY, node.y);
        }
      });

      if (minX === Infinity) return; // No descendants found

      // Add padding
      const padding = 100;
      minX -= padding;
      maxX += padding;
      minY -= padding;
      maxY += padding;

      // Calculate target scale to fit bounds
      const boundsWidth = maxX - minX;
      const boundsHeight = maxY - minY;
      const targetScaleX = dimensions.width / boundsWidth;
      const targetScaleY = dimensions.height / boundsHeight;
      let targetScale = Math.min(targetScaleX, targetScaleY);

      // Ensure we reach at least T2 threshold
      const minScaleForT2 = T2_BASE / (NODE_WIDTH_WITH_PHOTO * PixelRatio.get());
      targetScale = Math.max(targetScale, minScaleForT2 * 1.2); // 20% above threshold
      targetScale = clamp(targetScale, minZoom, maxZoom);

      // Calculate center and target position
      const centerX = (minX + maxX) / 2;
      const centerY = (minY + maxY) / 2;
      const targetX = dimensions.width / 2 - centerX * targetScale;
      const targetY = dimensions.height / 2 - centerY * targetScale;

      // Animate to target
      scale.value = withTiming(targetScale, { duration: 500 });
      translateX.value = withTiming(targetX, { duration: 500 });
      translateY.value = withTiming(targetY, { duration: 500 });

      // Update saved values after animation
      setTimeout(() => {
        savedScale.value = targetScale;
        savedTranslateX.value = targetX;
        savedTranslateY.value = targetY;
      }, 500);
    },
    [indices, dimensions, minZoom, maxZoom],
  );

  // Handle FAB press - show unlinked person modal
  const handleFABPress = useCallback(() => {
    // TODO: Show add unlinked person modal
    // console.log('Add unlinked person');
  }, []);

  // Handle context menu actions
  const handleContextMenuAction = useCallback(
    action => {
      if (!contextMenuNode) return;

      switch (action) {
        case 'addChildren':
          setMultiAddParent({ id: contextMenuNode.id, name: contextMenuNode.name });
          setShowMultiAddModal(true);
          break;
        case 'edit':
          setEditingProfile(contextMenuNode);
          setShowEditModal(true);
          break;
        case 'viewDetails':
          setSelectedPersonId(contextMenuNode.id);
          break;
        case 'delete':
          Alert.alert('تأكيد الحذف', `هل أنت متأكد من حذف ${contextMenuNode.name}؟`, [
            { text: 'إلغاء', style: 'cancel' },
            {
              text: 'حذف',
              style: 'destructive',
              onPress: async () => {
                try {
                  const { error } = await supabase
                    .from('profiles')
                    .update({ deleted_at: new Date().toISOString() })
                    .eq('id', contextMenuNode.id);

                  if (error) throw error;
                  Alert.alert('نجح', 'تم حذف الملف الشخصي');
                  await loadTreeData();
                } catch (error) {
                  // console.error('Error deleting profile:', error);
                  Alert.alert('خطأ', 'فشل حذف الملف الشخصي');
                }
              },
            },
          ]);
          break;
      }
    },
    [contextMenuNode, setSelectedPersonId],
  );

  // Compose gestures
  const composed = Gesture.Simultaneous(panGesture, pinchGesture, tapGesture);

  // Helper function to get color based on generation
  const getGenerationColor = useCallback(generation => {
    if (generation === 1) return '#F59E0B'; // Root gets distinct gold/orange color

    const colors = [
      '#E53E3E', // Gen 1: Red (not used anymore)
      '#DD6B20', // Gen 2: Orange
      '#D69E2E', // Gen 3: Yellow
      '#38A169', // Gen 4: Green
      '#319795', // Gen 5: Teal
      '#3182CE', // Gen 6: Blue
      '#5A67D8', // Gen 7: Indigo
      '#805AD5', // Gen 8: Purple
      '#D53F8C', // Gen 9: Pink
      '#718096', // Gen 10+: Gray
    ];
    return colors[Math.min(generation - 1, colors.length - 1)];
  }, []);

  // Calculate node importance based on its position in the tree
  const getNodeImportance = useCallback(node => {
    if (node.generation === 1) return 1.0; // Root Node
    if (node.generation === 2 && node.children?.length > 0) return 0.8; // Hero Node
    if (node.generation === 2 || (node.generation === 3 && node.children?.length > 0)) return 0.6;
    return 0.3; // Standard Node
  }, []);

  // Calculate visual properties for all nodes based on scale and importance
  const calculateNodeVisuals = useCallback(
    (nodes, scale, getNodeImportance, getGenerationColor) => {
      const visuals = new Map();
      if (nodes.length === 0) return visuals;

      const interpolate = (val, in_s, in_e, out_s, out_e) =>
        clamp(
          out_s + ((val - in_s) / (in_e - in_s)) * (out_e - out_s),
          Math.min(out_s, out_e),
          Math.max(out_s, out_e),
        );

      // Smooth anti-scaling thresholds
      const ANTI_SCALE_START = 0.55;
      const ANTI_SCALE_END = 0.35;
      const ANTI_SCALE_CAP = 8.0;

      for (const node of nodes) {
        const importance = getNodeImportance(node);
        const hasPhoto = !!node.photo_url;

        // --- Landmark Logic (Root and Heroes) ---
        if (importance >= 0.8) {
          const baseScale = importance === 1.0 ? 1.15 : 1.0; // Root 15% larger
          let antiScaleFactor;

          if (scale >= ANTI_SCALE_START) {
            antiScaleFactor = 1;
          } else if (scale <= ANTI_SCALE_END) {
            antiScaleFactor = Math.min(baseScale / scale, ANTI_SCALE_CAP);
          } else {
            // Smoothstep interpolation in transition zone
            const t = (scale - ANTI_SCALE_END) / (ANTI_SCALE_START - ANTI_SCALE_END);
            const smooth = t * t * (3 - 2 * t);
            const maxScale = Math.min(baseScale / scale, ANTI_SCALE_CAP);
            antiScaleFactor = 1 + (maxScale - 1) * smooth;
          }

          visuals.set(node.id, {
            width: PILL_WIDTH * antiScaleFactor,
            height: PILL_HEIGHT * antiScaleFactor,
            borderRadius: (PILL_HEIGHT / 2) * antiScaleFactor,
            nameOpacity: 1, // Landmarks are always legible
            photoOpacity: 0, // Landmarks are always pills for clarity
            fontSize: 10 * antiScaleFactor,
            backgroundColor: Skia.Color('white'),
            borderWidth: importance === 1.0 ? 2 : 1.5, // Root has a thicker border
          });
          continue; // Skip to the next node
        }

        // --- Standard Node Logic ---
        const effectiveScale = scale + importance * 0.2;
        const detailLevel = clamp(
          interpolate(effectiveScale, STRUCTURE_THRESHOLD, DETAIL_THRESHOLD, 0, 1),
          0,
          1,
        );

        const baseWidth = hasPhoto ? NODE_WIDTH_WITH_PHOTO : NODE_WIDTH_TEXT_ONLY;
        const baseHeight = hasPhoto ? NODE_HEIGHT_WITH_PHOTO : NODE_HEIGHT_TEXT_ONLY;

        const width = interpolate(detailLevel, 0, 1, DOT_SIZE, baseWidth);
        const height = interpolate(detailLevel, 0, 1, DOT_SIZE, baseHeight);

        const genColor = Skia.Color(getGenerationColor(node.generation));
        const white = Skia.Color('white');
        const backgroundColor = Skia.Color(
          interpolate(detailLevel, 0, 0.3, genColor[0], white[0]),
          interpolate(detailLevel, 0, 0.3, genColor[1], white[1]),
          interpolate(detailLevel, 0, 0.3, genColor[2], white[2]),
          1,
        );

        visuals.set(node.id, {
          width,
          height,
          borderRadius: interpolate(detailLevel, 0, 1, height / 2, CORNER_RADIUS),
          nameOpacity: interpolate(detailLevel, 0.1, 0.4, 0, 1),
          photoOpacity: hasPhoto ? interpolate(detailLevel, 0.5, 0.8, 0, 1) : 0,
          fontSize: 11,
          backgroundColor,
          borderWidth: 1,
        });
      }
      return visuals;
    },
    [],
  );

  /* Obsolete functions removed - now using useConnectionSegments */

  // Render node with progressive detail based on zoom level

  const renderProgressiveNode = useCallback(
    (node, nodeVisuals) => {
      if (!node) return null;

      const detail = nodeVisuals.get(node.id);
      if (!detail) return null;

      const importance = getNodeImportance(node);
      const isSelected = selectedPersonId === node.id;

      const {
        width: nodeWidth,
        height: nodeHeight,
        borderRadius,
        photoOpacity,
        nameOpacity,
        fontSize,
        backgroundColor,
        borderWidth,
      } = detail;
      const x = node.x - nodeWidth / 2;
      const y = node.y - nodeHeight / 2;

      // If node is just a dot, render simply and exit
      if (nameOpacity === 0) {
        return (
          <Group key={node.id}>
            <RoundedRect
              x={x}
              y={y}
              width={nodeWidth}
              height={nodeHeight}
              r={borderRadius}
              color={backgroundColor}
            />
          </Group>
        );
      }

      return (
        <Group key={node.id}>
          {/* Shadow - only if node is large enough */}
          {nodeWidth > PILL_WIDTH * 0.8 && (
            <RoundedRect
              x={x + 1}
              y={y + 1}
              width={nodeWidth}
              height={nodeHeight}
              r={borderRadius}
              color="#00000015"
            />
          )}

          {/* Main card background */}
          <RoundedRect
            x={x}
            y={y}
            width={nodeWidth}
            height={nodeHeight}
            r={borderRadius}
            color={backgroundColor}
          />

          {/* Border */}
          <RoundedRect
            x={x}
            y={y}
            width={nodeWidth}
            height={nodeHeight}
            r={borderRadius}
            color={isSelected ? '#212121' : '#E0E0E0'}
            style="stroke"
            strokeWidth={borderWidth}
          />

          {/* Photo with progressive opacity */}
          {photoOpacity > 0 && node.photo_url && (
            <>
              {/* Photo placeholder circles */}
              <Circle cx={node.x} cy={node.y - 10} r={PHOTO_SIZE / 2} color="#F5F5F5" />
              <Circle
                cx={node.x}
                cy={node.y - 10}
                r={PHOTO_SIZE / 2}
                color="#E0E0E0"
                style="stroke"
                strokeWidth={1}
              />
              <ImageNode
                url={node.photo_url}
                x={node.x - PHOTO_SIZE / 2}
                y={node.y - 10 - PHOTO_SIZE / 2}
                width={PHOTO_SIZE}
                height={PHOTO_SIZE}
                radius={PHOTO_SIZE / 2}
                shouldLoad={photoOpacity > 0.5} // Only load if mostly visible
                scale={scale}
                nodeId={node.id}
                selectBucket={selectBucketWithHysteresis}
                opacity={photoOpacity}
              />
            </>
          )}

          {/* Name text with progressive opacity */}
          {nameOpacity > 0 &&
            (() => {
              const displayName = importance >= 0.8 ? node.name : node.name.split(' ')[0]; // Landmarks show full name
              // Apply opacity to text color
              const alpha = Math.round(nameOpacity * 255);
              const textColor = `#212121${alpha.toString(16).padStart(2, '0')}`;

              const nameParagraph = createArabicParagraph(
                displayName,
                'bold',
                fontSize,
                textColor,
                nodeWidth,
              );

              if (!nameParagraph) return null;

              // Position text based on whether photo is shown
              const textY =
                photoOpacity > 0.5 && node.photo_url
                  ? y + 68 // Below photo
                  : y + (nodeHeight - nameParagraph.getHeight()) / 2; // Centered

              return <Paragraph paragraph={nameParagraph} x={x} y={textY} width={nodeWidth} />;
            })()}
        </Group>
      );
    },
    [selectedPersonId, getNodeImportance],
  );

  // Create a derived value for the transform to avoid Reanimated warnings
  const transform = useDerivedValue(() => {
    return [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { scale: scale.value },
    ];
  });

  // Store current transform values to avoid accessing .value during render
  const [currentTransform, setCurrentTransform] = useState({ x: 0, y: 0, scale: 1 });

  // Update transform values when they change
  useAnimatedReaction(
    () => ({
      x: translateX.value,
      y: translateY.value,
      scale: scale.value,
    }),
    current => {
      runOnJS(setCurrentTransform)(current);
    },
  );

  // Calculate culled nodes (with loading fallback)
  const culledNodes = useMemo(() => {
    if (isLoading) return [];

    let candidateNodes;
    if (!spatialGrid) {
      candidateNodes = visibleNodes;
    } else {
      candidateNodes = spatialGrid.getVisibleNodes(
        {
          x: currentTransform.x,
          y: currentTransform.y,
          width: dimensions.width,
          height: dimensions.height,
        },
        currentTransform.scale,
        indices.idToNode,
      );
    }

    // Apply importance-based sorting
    const nodesWithImportance = candidateNodes.map(node => ({
      node,
      importance: getNodeImportance(node),
    }));

    // Sort by importance (descending)
    nodesWithImportance.sort((a, b) => b.importance - a.importance);

    // Apply cap, always keeping landmarks
    const result = [];
    let regularCount = 0;

    for (const item of nodesWithImportance) {
      if (item.importance >= 0.8) {
        // Always include landmarks
        result.push(item.node);
      } else if (regularCount < MAX_VISIBLE_NODES) {
        result.push(item.node);
        regularCount++;
      }
    }

    return result;
  }, [
    isLoading,
    spatialGrid,
    currentTransform,
    dimensions,
    indices.idToNode,
    visibleNodes,
    getNodeImportance,
  ]);

  // No longer needed - using progressive render directly

  // Keep gestureStateRef in sync for tap gesture
  useEffect(() => {
    gestureStateRef.current = {
      transform: currentTransform,
      indices,
      visibleNodes: culledNodes,
      fitScale,
      treeBounds,
    };
  }, [currentTransform, indices, culledNodes, fitScale, treeBounds]);

  // Calculate visual properties for all nodes
  const nodeVisuals = useMemo(
    () =>
      calculateNodeVisuals(nodes, currentTransform.scale, getNodeImportance, getGenerationColor),
    [nodes, currentTransform.scale, getNodeImportance, getGenerationColor, calculateNodeVisuals],
  );

  // Create culledNodeIds set for connection filtering
  const culledNodeIds = useMemo(() => new Set(culledNodes.map(n => n.id)), [culledNodes]);

  // Filter visible connections based on culled nodes
  const visibleConnections = useMemo(() => {
    const visible = connections.filter(conn => {
      // Parent must be visible
      if (!culledNodeIds.has(conn.parent.id)) return false;
      // At least one child must be visible
      return conn.children.some(child => culledNodeIds.has(child.id));
    });

    // DEBUG: Track connection visibility changes
    // if (__DEV__ && visible.length !== prevVisibleConnectionsRef.current) {
    //   console.log(`🔗 CONNECTIONS: ${prevVisibleConnectionsRef.current}→${visible.length}`);
    //   prevVisibleConnectionsRef.current = visible.length;
    // }

    return visible;
  }, [connections, culledNodeIds]);

  // Calculate all connection segments using the pre-calculated connection map
  const connectionSegments = useConnectionSegments(
    visibleConnections,
    indices.idToNode,
    indices.parentToChildren,
    nodeVisuals,
    currentTransform.scale,
    getNodeImportance,
    culledNodeIds,
    groupVisibilityLatchRef,
  );

  // Auto-frame trunk on overview entry
  useEffect(() => {
    const isInOverview = currentTransform.scale < STRUCTURE_THRESHOLD;

    if (!wasInOverview && isInOverview && !isLoading) {
      // Just entered overview - auto-frame trunk
      const heroes = [...indices.idToNode.values()].filter(node => getNodeImportance(node) === 0.8);

      if (heroes.length > 0) {
        const heroXs = heroes.map(h => h.x);
        const minX = Math.min(...heroXs);
        const maxX = Math.max(...heroXs);
        const centerX = (minX + maxX) / 2;

        // Calculate trunk bus Y
        const rootNode = [...indices.idToNode.values()].find(n => n.generation === 1);
        if (rootNode) {
          const rootVisuals = nodeVisuals.get(rootNode.id);
          if (rootVisuals) {
            const trunkBusY =
              rootNode.y + rootVisuals.height / 2 + BUS_GAP_LANDMARK_PX / currentTransform.scale;

            // Animate to frame trunk with margin
            const margin = 100 / currentTransform.scale;
            const targetWidth = maxX - minX + 2 * margin;
            const targetScale = Math.min(dimensions.width / targetWidth, currentTransform.scale);

            scale.value = withSpring(targetScale);
            translateX.value = withSpring(-centerX);
            translateY.value = withSpring(-trunkBusY);
          }
        }
      }
    }

    setWasInOverview(isInOverview);
  }, [
    currentTransform.scale,
    wasInOverview,
    isLoading,
    indices,
    getNodeImportance,
    nodeVisuals,
    dimensions,
    scale,
    translateX,
    translateY,
  ]);

  // Show loading state
  if (isLoading) {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#f3f4f6',
        }}>
        <ActivityIndicator size="large" color="#1f2937" />
        <Text style={{ marginTop: 16, fontSize: 16, color: '#6b7280' }}>جاري تحميل الشجرة...</Text>
      </View>
    );
  }

  // Update frame stats
  frameStatsRef.current.nodesDrawn = culledNodes.length;
  frameStatsRef.current.edgesDrawn = connectionSegments.length;

  return (
    <View className="flex-1 bg-gray-100">
      <GestureDetector gesture={composed}>
        <Canvas style={{ flex: 1 }}>
          <Group transform={transform}>
            {/* Layer 1: Standard connections (underneath) */}
            {connectionSegments
              .filter(seg => seg.layer === 1)
              .map((seg, index) => {
                const width = seg.type === 'v' ? seg.worldThickness : seg.x2 - seg.x1;
                const height = seg.type === 'h' ? seg.worldThickness : seg.y2 - seg.y1;
                const x = seg.type === 'v' ? seg.x - seg.worldThickness / 2 : seg.x1;
                const y = seg.type === 'h' ? seg.y - seg.worldThickness / 2 : seg.y1;

                if (width <= 0 || height <= 0) return null;

                return (
                  <RoundedRect
                    key={`${seg.role}-${seg.type}-${index}`}
                    x={x}
                    y={y}
                    width={width}
                    height={height}
                    r={seg.worldThickness / 2}
                    color={LINE_COLOR}
                  />
                );
              })}

            {/* Layer 2: Trunk connections (on top of standard) */}
            {connectionSegments
              .filter(seg => seg.layer === 2)
              .map((seg, index) => {
                const width = seg.type === 'v' ? seg.worldThickness : seg.x2 - seg.x1;
                const height = seg.type === 'h' ? seg.worldThickness : seg.y2 - seg.y1;
                const x = seg.type === 'v' ? seg.x - seg.worldThickness / 2 : seg.x1;
                const y = seg.type === 'h' ? seg.y - seg.worldThickness / 2 : seg.y1;

                if (width <= 0 || height <= 0) return null;

                return (
                  <RoundedRect
                    key={`${seg.role}-${seg.type}-${index}`}
                    x={x}
                    y={y}
                    width={width}
                    height={height}
                    r={seg.worldThickness / 2}
                    color={LINE_COLOR}
                  />
                );
              })}

            {/* Nodes render last (on top of all connections) */}
            {culledNodes.map(node => renderProgressiveNode(node, nodeVisuals))}
          </Group>
        </Canvas>
      </GestureDetector>

      {/* Add navigation button */}
      <NavigateToRootButton
        nodes={nodes}
        viewport={dimensions}
        sharedValues={{ translateX, translateY, scale }}
      />

      {/* Admin components */}
      {isAdminMode && (
        <>
          <SystemStatusIndicator />
          <GlobalFAB onPress={handleFABPress} visible={true} />
        </>
      )}

      {/* Cache stats in dev mode - REMOVED to prevent render loops */}
      {/* {__DEV__ && (
        <View style={{
          position: 'absolute',
          bottom: 100,
          left: 10,
          backgroundColor: 'rgba(0,0,0,0.8)',
          padding: 8,
          borderRadius: 8,
        }}>
          <Text style={{ color: 'white', fontSize: 11, fontFamily: 'monospace' }}>
            {(() => {
              const stats = skiaImageCache.getStats();
              return `Cache: ${stats.entries} images\n${stats.totalMB}MB / ${stats.budgetMB}MB (${stats.utilization})`;
            })()}
          </Text>
        </View>
      )} */}

      {/* Node Context Menu */}
      <NodeContextMenu
        visible={showContextMenu}
        position={contextMenuPosition}
        node={contextMenuNode}
        onClose={() => setShowContextMenu(false)}
        onAction={handleContextMenuAction}
      />

      {/* Multi-add children modal */}
      {multiAddParent && (
        <MultiAddChildrenModal
          visible={showMultiAddModal}
          onClose={() => {
            setShowMultiAddModal(false);
            setMultiAddParent(null);
          }}
          parentId={multiAddParent.id}
          parentName={multiAddParent.name}
          parentGender={contextMenuNode?.gender || 'male'}
        />
      )}

      {/* Edit Profile Modal */}
      <EditProfileScreen
        visible={showEditModal}
        profile={editingProfile}
        onClose={() => {
          setShowEditModal(false);
          setEditingProfile(null);
        }}
        onSave={async updatedProfile => {
          // Reload tree data to reflect changes
          await loadTreeData();
        }}
      />
    </View>
  );
};

export default TreeView;
