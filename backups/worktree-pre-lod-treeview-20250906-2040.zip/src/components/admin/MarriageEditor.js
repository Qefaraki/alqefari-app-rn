import React, { useEffect, useMemo, useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Alert,
  Animated,
  Dimensions,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import GlassButton from '../glass/GlassButton';
import profilesService from '../../services/profiles';
import { handleSupabaseError } from '../../services/supabase';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function MarriageEditor({ visible, onClose, person, onCreated }) {
  const [mode, setMode] = useState('create');
  const [spouseName, setSpouseName] = useState('');
  const [parsedName, setParsedName] = useState({
    firstName: '',
    middleChain: [],
    familyName: '',
  });

  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);
  const [selectedSpouse, setSelectedSpouse] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const scaleAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;
  const confirmationOpacity = useRef(new Animated.Value(0)).current;

  // Auto-determine spouse gender (opposite of person's gender)
  const spouseGender = useMemo(
    () => (person?.gender === 'male' ? 'female' : 'male'),
    [person?.gender],
  );

  // Dynamic labels based on person's gender - more conversational
  const modalTitle = useMemo(() => {
    if (!person) return '';
    return person.gender === 'male'
      ? `إضافة زوجة لـ ${person.name}`
      : `إضافة زوج لـ ${person.name}`;
  }, [person]);

  const inputLabel = useMemo(
    () => (person?.gender === 'male' ? 'اسم الزوجة' : 'اسم الزوج'),
    [person?.gender],
  );

  // Helper to get user-friendly error messages
  const getUserFriendlyError = error => {
    const errorMessage = error?.message || error;

    // Map technical errors to Arabic
    if (errorMessage?.includes('PCRST202') || errorMessage?.includes('duplicate')) {
      return 'هذا الشخص موجود بالفعل في شجرة العائلة';
    }
    if (errorMessage?.includes('network') || errorMessage?.includes('fetch')) {
      return 'تأكد من اتصال الإنترنت وحاول مرة أخرى';
    }
    if (errorMessage?.includes('23505')) {
      return 'هذا الزواج مسجل مسبقاً';
    }

    // Use handleSupabaseError for other codes
    return handleSupabaseError(error) || 'حدث خطأ. حاول مرة أخرى';
  };

  const parseName = useCallback(fullName => {
    const trimmed = fullName?.trim() || '';
    if (!trimmed) return null;

    const words = trimmed.split(/\s+/).filter(w => w.length > 0);
    if (words.length < 2) return null;

    return {
      firstName: words[0],
      middleChain: words.slice(1, -1),
      familyName: words[words.length - 1],
    };
  }, []);

  const formatDisplayName = useCallback(() => {
    if (!parsedName.firstName || !parsedName.familyName) return '';

    const { firstName, middleChain, familyName } = parsedName;
    const genderPrefix = spouseGender === 'male' ? 'بن' : 'بنت';

    // Build the name with proper Arabic formatting
    let displayName = firstName;
    if (middleChain.length > 0) {
      displayName += ` ${genderPrefix} ${middleChain.join(' ')}`;
    }

    // Always show family name in the format "من عائلة X"
    displayName += ` من عائلة ${familyName}`;

    return displayName;
  }, [parsedName, spouseGender]);

  useEffect(() => {
    if (visible) {
      setMode('create');
      setSpouseName('');
      setParsedName({
        firstName: '',
        middleChain: [],
        familyName: '',
      });
      setQuery('');
      setResults([]);
      setSelectedSpouse(null);

      Animated.parallel([
        Animated.spring(scaleAnim, {
          toValue: 1,
          tension: 50,
          friction: 7,
          useNativeDriver: true,
        }),
        Animated.timing(opacityAnim, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(scaleAnim, {
          toValue: 0,
          duration: 150,
          useNativeDriver: true,
        }),
        Animated.timing(opacityAnim, {
          toValue: 0,
          duration: 150,
          useNativeDriver: true,
        }),
        Animated.timing(confirmationOpacity, {
          toValue: 0,
          duration: 150,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [visible, scaleAnim, opacityAnim, confirmationOpacity]);

  const handleNameChange = useCallback(
    input => {
      setSpouseName(input);
      const parsed = parseName(input);

      if (parsed) {
        setParsedName(parsed);
        Animated.timing(confirmationOpacity, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }).start();
      } else {
        setParsedName({
          firstName: '',
          middleChain: [],
          familyName: '',
        });
        Animated.timing(confirmationOpacity, {
          toValue: 0,
          duration: 150,
          useNativeDriver: true,
        }).start();
      }
    },
    [parseName, confirmationOpacity],
  );

  const performSearch = useCallback(
    async text => {
      const q = text?.trim();
      if (!q || q.length < 2) {
        setResults([]);
        return;
      }
      setLoading(true);
      try {
        const { data, error } = await profilesService.searchProfiles(q, 30, 0);
        if (error) throw new Error(error);
        const filtered = (data || [])
          .filter(p => p.id !== person.id)
          .filter(p => p.gender === spouseGender);
        setResults(filtered);
      } catch (e) {
        setResults([]);
      } finally {
        setLoading(false);
      }
    },
    [person?.id, spouseGender],
  );

  useEffect(() => {
    if (mode === 'link') {
      const t = setTimeout(() => performSearch(query), 300);
      return () => clearTimeout(t);
    }
  }, [query, performSearch, mode]);

  const handleCreateNewSpouse = async () => {
    const trimmedName = spouseName.trim();

    if (!trimmedName) {
      Alert.alert('عذراً', 'من فضلك اكتب الاسم أولاً');
      return;
    }

    const nameWords = trimmedName.split(/\s+/).filter(w => w.length > 0);
    if (nameWords.length < 2) {
      Alert.alert(
        'الاسم غير مكتمل',
        'من فضلك اكتب الاسم الأول واسم العائلة على الأقل\n\nمثال: نورة القحطاني',
        [{ text: 'حسناً', style: 'default' }],
      );
      return;
    }

    setSubmitting(true);
    try {
      const { data: newProfile, error: profileError } = await profilesService.createProfile({
        name: trimmedName,
        gender: spouseGender, // Auto-determined gender
        munasib: parsedName.familyName || null,
        father_id: null,
        mother_id: null,
      });

      if (profileError) throw new Error(profileError);
      if (!newProfile) throw new Error('فشل إنشاء الملف الشخصي');

      const husband_id = person.gender === 'male' ? person.id : newProfile.id;
      const wife_id = person.gender === 'female' ? person.id : newProfile.id;

      const { data: marriage, error: marriageError } = await profilesService.createMarriage({
        husband_id,
        wife_id,
        munasib: parsedName.familyName || null,
      });

      if (marriageError) throw new Error(marriageError);

      if (onCreated) onCreated(marriage);
      Alert.alert('تم بنجاح', 'تم إضافة الزوج/الزوجة إلى الشجرة');
      onClose();
    } catch (e) {
      Alert.alert('عذراً', getUserFriendlyError(e), [
        { text: 'حاول مرة أخرى', style: 'default' },
        { text: 'إلغاء', style: 'cancel' },
      ]);
    } finally {
      setSubmitting(false);
    }
  };

  const handleLinkExisting = async () => {
    if (!selectedSpouse) {
      Alert.alert('تنبيه', 'يرجى اختيار الزوج/الزوجة');
      return;
    }
    setSubmitting(true);
    try {
      const husband_id = person.gender === 'male' ? person.id : selectedSpouse.id;
      const wife_id = person.gender === 'female' ? person.id : selectedSpouse.id;
      const payload = {
        husband_id,
        wife_id,
      };
      const { data, error } = await profilesService.createMarriage(payload);
      if (error) throw new Error(error);
      if (onCreated) onCreated(data);
      Alert.alert('تم بنجاح', 'تم تسجيل الزواج في الشجرة');
      onClose();
    } catch (e) {
      Alert.alert('عذراً', getUserFriendlyError(e));
    } finally {
      setSubmitting(false);
    }
  };

  const renderCreateMode = () => (
    <ScrollView
      style={{ flex: 1 }}
      contentContainerStyle={styles.scrollContentContainer}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled">
      <View style={styles.formGroup}>
        <Text style={styles.label}>{inputLabel}</Text>
        <TextInput
          style={styles.input}
          placeholder="مثال: نورة خالد القحطاني"
          placeholderTextColor="#999999"
          value={spouseName}
          onChangeText={handleNameChange}
          textAlign="right"
          autoCorrect={false}
          autoCapitalize="words"
        />
        <Text style={styles.helpText}>
          يُفضل كتابة: الاسم الأول + اسم الأب + اسم العائلة
        </Text>
      </View>

      {parsedName.firstName && parsedName.familyName && (
        <Animated.View
          style={[
            styles.namePreview,
            {
              opacity: confirmationOpacity,
              transform: [
                {
                  translateY: confirmationOpacity.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-10, 0],
                  }),
                },
              ],
            },
          ]}>
          <View style={styles.previewContent}>
            <View style={styles.previewIcon}>
              <Ionicons name="checkmark-circle" size={24} color="#34C759" />
            </View>
            <View style={styles.previewTextContainer}>
              <Text style={styles.previewLabel}>سيتم التسجيل باسم:</Text>
              <Text style={styles.previewText}>{formatDisplayName()}</Text>
            </View>
          </View>
        </Animated.View>
      )}

      <TouchableOpacity style={styles.switchModeLink} onPress={() => setMode('link')}>
        <Ionicons name="link-outline" size={20} color="#007AFF" />
        <Text style={styles.switchModeLinkText}>أو اختر من الأشخاص الموجودين في الشجرة</Text>
      </TouchableOpacity>
    </ScrollView>
  );

  const renderLinkMode = () => (
    <View style={{ flex: 1, backgroundColor: '#F2F2F7' }}>
      <View style={{ padding: 24, paddingBottom: 0 }}>
        <View style={styles.searchBar}>
          <Ionicons name="search" size={22} color="#666666" />
          <TextInput
            style={styles.searchInput}
            placeholder="ابحث بالاسم..."
            placeholderTextColor="#999999"
            value={query}
            onChangeText={setQuery}
            textAlign="right"
            returnKeyType="search"
          />
        </View>
      </View>

      <ScrollView
        style={styles.resultsContainer}
        contentContainerStyle={[styles.resultsContent, { paddingHorizontal: 24 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}>
        {loading ? (
          <View style={styles.loadingRow}>
            <ActivityIndicator color="#007AFF" size="large" />
            <Text style={styles.loadingText}>جاري البحث...</Text>
          </View>
        ) : results.length === 0 && query.length > 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="search-outline" size={56} color="#999999" />
            <Text style={styles.emptyStateText}>لم نجد نتائج</Text>
            <Text style={styles.emptyStateHint}>جرب اسماً آخر</Text>
          </View>
        ) : (
          results.map(p => {
            const isActive = selectedSpouse?.id === p.id;
            return (
              <TouchableOpacity
                key={p.id}
                style={[styles.resultRow, isActive && styles.resultRowActive]}
                onPress={() => setSelectedSpouse(p)}
                activeOpacity={0.7}>
                <View style={{ flex: 1, alignItems: 'flex-end' }}>
                  <Text style={[styles.resultName, isActive && styles.resultNameActive]}>
                    {p.name}
                  </Text>
                  <Text style={[styles.resultMeta, isActive && styles.resultMetaActive]}>
                    HID: {p.hid}
                  </Text>
                </View>
                {isActive && <Ionicons name="checkmark-circle" size={22} color="#FFFFFF" />}
              </TouchableOpacity>
            );
          })
        )}
      </ScrollView>

      <View style={{ padding: 24, paddingTop: 12 }}>
        <TouchableOpacity style={styles.switchModeLink} onPress={() => setMode('create')}>
          <Ionicons name="add-circle-outline" size={20} color="#007AFF" />
          <Text style={styles.switchModeLinkText}>أو أضف شخصاً جديداً</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (!visible) return null;

  return (
    <Modal transparent visible={visible} animationType="none" onRequestClose={onClose}>
      <KeyboardAvoidingView
        style={styles.overlay}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={onClose}>
          <Animated.View
            style={[
              styles.modalContainer,
              {
                transform: [{ scale: scaleAnim }],
                opacity: opacityAnim,
              },
            ]}>
            <View style={styles.modal}>
              {/* Modern iOS-style header */}
              <BlurView intensity={100} style={styles.headerBlur}>
                <View style={styles.header}>
                  <TouchableOpacity onPress={onClose} style={styles.closeButton}>
                    <View style={styles.closeButtonCircle}>
                      <Ionicons name="close" size={20} color="#666" />
                    </View>
                  </TouchableOpacity>
                  <View style={styles.titleContainer}>
                    <Text style={styles.title}>{modalTitle}</Text>
                    {mode === 'link' && (
                      <Text style={styles.subtitle}>اختر شخصاً من الشجرة</Text>
                    )}
                  </View>
                  <View style={{ width: 40 }} />
                </View>
              </BlurView>

              <View style={styles.content}>
                {mode === 'create' ? renderCreateMode() : renderLinkMode()}
              </View>

              {/* Modern iOS-style footer */}
              <BlurView intensity={95} style={styles.footerBlur}>
                <View style={styles.footer}>
                  <GlassButton
                    title={
                      mode === 'create'
                        ? parsedName.firstName && parsedName.familyName
                          ? 'إضافة'
                          : 'اكتب الاسم أولاً'
                        : selectedSpouse
                          ? 'ربط الزواج'
                          : 'اختر شخصاً أولاً'
                    }
                    onPress={mode === 'create' ? handleCreateNewSpouse : handleLinkExisting}
                    loading={submitting}
                    disabled={
                      mode === 'create'
                        ? !parsedName.firstName || !parsedName.familyName
                        : !selectedSpouse
                    }
                    style={{ width: '100%' }}
                    variant={
                      parsedName.firstName && parsedName.familyName ? 'primary' : 'secondary'
                    }
                  />
                </View>
              </BlurView>
            </View>
          </Animated.View>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: SCREEN_WIDTH * 0.92,
    maxWidth: 440,
    height: '70%',
    maxHeight: 600,
  },
  modal: {
    flex: 1,
    flexDirection: 'column',
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.25,
    shadowRadius: 30,
    elevation: 20,
  },
  headerBlur: {
    overflow: 'hidden',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(0, 0, 0, 0.08)',
  },
  closeButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(120, 120, 128, 0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: '#000',
    textAlign: 'center',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    fontWeight: '400',
    color: '#8E8E93',
    textAlign: 'center',
  },
  content: {
    flex: 1,
    backgroundColor: '#F2F2F7',
  },
  scrollContentContainer: {
    flexGrow: 1,
    padding: 24,
    paddingBottom: 20,
  },
  formGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    color: '#000000',
    marginBottom: 12,
    textAlign: 'right',
    fontWeight: '500',
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingHorizontal: 18,
    paddingVertical: 18,
    fontSize: 18,
    color: '#000',
    borderWidth: 1,
    borderColor: 'rgba(0, 0, 0, 0.06)',
    minHeight: 60,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  helpText: {
    fontSize: 14,
    color: '#666666',
    marginTop: 10,
    textAlign: 'right',
    lineHeight: 20,
  },
  namePreview: {
    marginBottom: 20,
  },
  previewContent: {
    backgroundColor: 'rgba(52, 199, 89, 0.06)',
    borderRadius: 14,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: 'rgba(52, 199, 89, 0.2)',
  },
  previewIcon: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(52, 199, 89, 0.1)',
    borderRadius: 20,
  },
  previewTextContainer: {
    flex: 1,
    alignItems: 'flex-end',
  },
  previewLabel: {
    fontSize: 12,
    color: '#34C759',
    fontWeight: '600',
    marginBottom: 4,
  },
  previewText: {
    fontSize: 17,
    color: '#000',
    fontWeight: '500',
    textAlign: 'right',
  },
  switchModeLink: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 20,
    marginTop: 16,
    backgroundColor: 'rgba(0, 122, 255, 0.06)',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(0, 122, 255, 0.12)',
    minHeight: 56,
  },
  switchModeLinkText: {
    fontSize: 16,
    color: '#007AFF',
    fontWeight: '500',
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderWidth: 1,
    borderColor: 'rgba(0, 0, 0, 0.06)',
    minHeight: 60,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  searchInput: {
    flex: 1,
    fontSize: 18,
    marginLeft: 12,
    color: '#000',
  },
  resultsContainer: {
    flex: 1,
    marginTop: 20,
  },
  resultsContent: {
    paddingBottom: 20,
  },
  loadingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 24,
    gap: 12,
    justifyContent: 'center',
  },
  loadingText: {
    fontSize: 15,
    color: '#8E8E93',
  },
  resultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingHorizontal: 18,
    paddingVertical: 18,
    marginBottom: 12,
    minHeight: 72,
    borderWidth: 1,
    borderColor: 'rgba(0, 0, 0, 0.06)',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  resultRowActive: {
    backgroundColor: '#007AFF',
    borderColor: '#007AFF',
  },
  resultName: {
    fontSize: 18,
    color: '#000',
    fontWeight: '500',
  },
  resultNameActive: {
    color: '#FFFFFF',
  },
  resultMeta: {
    fontSize: 13,
    color: '#8E8E93',
    marginTop: 4,
  },
  resultMetaActive: {
    color: 'rgba(255, 255, 255, 0.8)',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyStateText: {
    fontSize: 18,
    color: '#666666',
    marginTop: 16,
    fontWeight: '500',
  },
  emptyStateHint: {
    fontSize: 14,
    color: '#999999',
    marginTop: 8,
  },
  footerBlur: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  footer: {
    padding: 20,
    paddingBottom: Platform.OS === 'ios' ? 34 : 20,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(0, 0, 0, 0.08)',
  },
});
