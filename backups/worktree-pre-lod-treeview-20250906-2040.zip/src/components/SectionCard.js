import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const SectionCard = ({ title, children, style, contentStyle, actions }) => {
  const showHeader = Boolean(title) || Boolean(actions);
  return (
    <View style={[styles.container, style]}>
      {showHeader && (
        <View style={styles.headerRow}>
          {/* Actions on the left (for RTL), title on the right */}
          <View style={styles.actionsContainer}>{actions}</View>
          {title ? <Text style={styles.title}>{title}</Text> : <View />}
        </View>
      )}
      <View style={[styles.content, contentStyle]}>{children}</View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginVertical: 8,
  },
  headerRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1a1a1a',
    textAlign: 'right',
    fontFamily: 'SF Arabic',
  },
  actionsContainer: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
  },
  content: {
    flex: 1,
  },
});

export default SectionCard;
