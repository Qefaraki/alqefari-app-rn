# AHDAF Application Project Roadmap

## Latest Updates

### Landmark-Based LOD System (2025-01-05)

- ✅ Implemented landmark-based navigation with anti-scaling
  - Root and Hero nodes remain legible anchors when zoomed out
  - Anti-scaling activates only below LANDMARK_BEHAVIOR_THRESHOLD (0.4)
  - Root gets 1.2x base anti-scale, Heroes get 1.0x base
  - Landmarks always display as pills with full names, never dots
- ✅ Architectural improvements
  - Created centralized useNodeVisuals hook as single source of truth
  - Removed conflicting getNodeDetail function
  - Updated all dependent functions to use nodeVisuals Map
  - Removed unnecessary highlight halos per design decisions
- ✅ Smooth transitions
  - Standard nodes follow normal LOD transitions (cards → pills → dots)
  - Landmarks scale inversely with zoom below threshold
  - All nodes normalize to standard sizes when zoomed in
  - Clean, professional appearance without visual clutter
- ✅ Enhanced anti-scaling behavior
  - Added smooth transition zone from scale 0.4 to 0.3
  - Eliminated abrupt size jumps with interpolation
  - Increased max growth from 3.5x to 7.0x for dramatic effect
  - Created fluid, continuous growth as user zooms out
- ✅ Implemented hybrid morphing edge system
  - Landmark connections (Root/Hero) morph from lines to thick anchor bars
  - Standard connections shrink strokeWidth to 0 for elegant fade
  - Uses RoundedRect for landmarks with smooth width/height animations
  - All morphing transitions occur between scale 0.4 to 0.2
  - Provides visual hierarchy: important connections thicken, others disappear
- ✅ Fixed landmark connectivity and navigation
  - Connections maintain full height instead of shrinking to 0
  - Added inter-landmark trunk connections between landmark groups
  - Simplified anti-scaling for continuous growth at all zoom levels
  - Increased max growth from 7x to 20x for dramatic scaling
  - Result: Fully connected landmark highway for seamless navigation
- ✅ Enabled unlimited scaling and proper alignment
  - Removed all limits on anti-scaling for indefinite growth
  - Fixed connection alignment by using visual properties directly
  - Ensures connections properly touch anti-scaled nodes
  - Landmark nodes can now grow continuously as you zoom out
- ✅ Implemented connection anti-scaling
  - Connections now scale continuously beyond 0.2 zoom threshold
  - Added connectionAntiScale factor for extreme zoom levels
  - All landmark connections (vertical, horizontal, trunk) scale proportionally
  - Maintains visibility of connections at any zoom level
- ✅ Implemented elegant connection visibility rule
  - Pre-calculated connection map with useConnectionSegments hook
  - Connections to children hide when children become dots (nameOpacity < 0.1)
  - Eliminates duplicate lines and visual clutter
  - Clean single vertical anchor from landmarks when zoomed out
  - Replaced complex renderEdgesBatched with simple segment renderer

### LOD System Fixes (2025-01-05)

- ✅ Fixed LOD not activating early enough
  - Removed PixelRatio.get() double-scaling from tier calculations
  - Updated thresholds: T1_BASE 48→140, T2_BASE 24→80
  - Fixed image bucket selection to use screen dp only
- ✅ Added dynamic zoom-to-fit functionality
  - Calculate fitScale based on tree bounds
  - Use Math.min(minZoom, fitScale) for localMinZoom
  - Added zoomToFit function with spring animation
- ✅ Improved Tier 3 aggregation
  - Force aggregation when near fit scale or overloaded
  - Added forceTier3 logic: scale <= fitScale \* 1.5 or nodes > 70% cap
- ✅ Enhanced Tier 2 pill visibility
  - Added minimum width PILL_MIN_W = 56
  - Scale fontSize with node.\_scale for readability
- ✅ Updated pinch gesture to use localMinZoom
  - Ensures entire tree can be viewed

### LOD Connection Rendering Fixes - Topology-First Architecture (2025-01-06)

- ✅ Fixed critical visual bugs in LOD connection system
  - Vertical overlap: connections no longer intrude into node pills
  - Landmark jump: smooth anti-scaling with smoothstep interpolation
  - Partial hide/disconnect: persistent group visibility with hysteresis
  - Stub artifacts: morph retraction shrinks lines as they fade
  - Trunk cohesion: unified trunk bus connects all heroes
  - Inconsistent visibility: importance-based culling keeps landmarks visible
- ✅ Implemented Topology-First Architecture
  - Added persistent group visibility latch using useRef
  - Increased SpatialGrid cap from MAX_VISIBLE_NODES to 1000
  - Smooth landmark anti-scaling with transition zone (0.35-0.55)
  - Anti-scale cap increased to 8.0 for dramatic effect
- ✅ Complete refactor of useConnectionSegments hook
  - Unified trunk calculation and rendering
  - Group gating with persistent hysteresis
  - Thickness-aware endpoints (offset by worldThickness/2)
  - Morph retraction for fading lines
  - Role-based deduplication keys
  - Two-pass rendering: standard connections then trunk
- ✅ Enhanced node culling and visibility
  - Updated visibleConnections to use culledNodes
  - Importance-aware node culling (landmarks always visible)
  - Auto-frame trunk on overview entry
- ✅ Pixel-first math implementation
  - World-space thickness conversion (worldThickness = pixelThickness/scale)
  - Consistent thickness curves for all connection types
  - Proper handling of vertical and horizontal segments

### Bug Fixes (2025-01-05)

- ✅ Fixed React hooks order violation in TreeView component
  - Moved all hooks (useCallback, useMemo, useEffect) before conditional returns
  - Fixed "Rendered more hooks than during the previous render" error
  - Ensured hooks are called in the same order on every render
- ✅ Fixed Reanimated value access during render
  - Created currentTransform state to avoid accessing .value during render
  - Used useAnimatedReaction to sync transform values
  - Updated gesture handlers to use synced state values

### Documentation Cleanup (2025-09-04)

- ✅ Reviewed all documentation files against current codebase
- ✅ Updated backend-implementation.md to reflect actual implementation
- ✅ Created optimized CLAUDE.md for AI assistant context
- ✅ Removed outdated migration guide and security vulnerabilities
- ✅ Verified validation functions and admin operations
- ✅ Fixed trigger_layout_recalc_async naming mismatch
- ✅ Documented missing features (marriage UI, get_person_with_relations)

## Phase 5: High-Velocity Admin Toolkit & Backend Engine

### ✅ Completed

#### Admin Edit Mode - Phase 1: Core Identity Fields (2025-09-01)

- ✅ Created NameEditor component with premium iOS-style text input
  - Large 36px font matching current design
  - Animated focus states with spring physics
  - Clear button with smooth animations
  - Real-time validation (min 2 characters)
  - RTL support with SF Arabic font

- ✅ Created BioEditor component with expanding textarea
  - Auto-expanding from 3 to 10 lines
  - Glass card design with CardSurface
  - Arabic numeral character counter (٢٥٠/٥٠٠)
  - Smooth animations and haptic feedback
  - Internal scroll when max height reached

- ✅ Created SiblingOrderStepper component (HIGH PRIORITY)
  - Premium glass-style stepper control
  - Animated button presses with spring physics
  - Haptic feedback (light, success, error)
  - Arabic number display
  - Live preview text showing position
  - Disabled state for minus at 0

- ✅ Integrated all components into ProfileSheet
  - Name editing in hero section
  - Bio editing with character limit
  - Sibling order in Information section
  - Proper data flow through editedData state

- ✅ Fixed native animation conflicts in NameEditor
  - Separated animated values for different purposes
  - Used state-based styling for border color
  - All animations now properly use native driver

- ✅ Fixed database constraint violations on save
  - Convert empty strings to null for nullable fields
  - Added client-side email validation
  - Properly handle all optional fields in database

- ✅ Implemented efficient single-node updates
  - Added updateNode, addNode, removeNode to Zustand store
  - Tree nodes update instantly after editing
  - Real-time sync updates individual nodes, not entire tree
  - Scales to trees of any depth without performance impact

- ✅ Fixed TreeView state management
  - Removed duplicate local state in TreeView
  - Single source of truth using Zustand store
  - Tree automatically re-renders when any component updates data
  - Fixes issue where edits weren't visible until restart

- ✅ Created compact admin interface
  - Removed large "شجرة عائلة القفاري" title taking up space
  - Created CompactAdminBar with glass morphism effect
  - Single row design: user | toggle | control panel
  - Reduced header from ~200px to ~50px
  - Added collapse option for cleaner view
  - Floating admin login when not authenticated

- ✅ Implemented comprehensive debug logging system (2025-09-02)
  - Canvas coordinate tracking (verifies nodes never move)
  - Viewport bounds calculations with transform details
  - Node visibility transitions (entry/exit tracking)
  - Connection visibility changes
  - Pinch gesture transform calculations
  - Tap coordinate transformations
  - Node rendering position verification
- ✅ Fixed Reanimated crash in debug logging (2025-09-03)
  - Removed inline runOnJS from useAnimatedReaction
  - Fixed segmentation fault in simulator
  - Preserved other debug logs for troubleshooting
- ✅ Optimized debug logging to reduce spam (2025-09-03)
  - Removed per-frame rendering logs
  - Condensed all logs to single-line summaries
  - Added helpful debug guide on startup
  - Made logs easily shareable for troubleshooting

- ✅ Identified and fixed zoom jumping on physical devices (2025-09-03)
  - Root cause: Viewport culling causing massive visibility changes
  - Increased VIEWPORT_MARGIN from 200 to 800 pixels
  - Added dynamic margin that scales with zoom level
  - Rounded focal points to prevent float precision issues
  - Added warnings for large visibility changes

- ✅ Fixed physical device gesture handling differences (2025-09-03)
  - Issue: Physical devices send duplicate gesture events with stuck scale values
  - Added gesture debouncing to skip duplicate scale updates within 16ms
  - Implemented focal point stabilization using stored values from gesture start
  - Added 1% scale change threshold to prevent tiny updates
  - Normalized touch coordinates to even numbers to reduce drift
  - Throttled viewport bounds updates to 60fps maximum

- ✅ Completely fixed zoom jumping on physical iOS devices (2025-09-04)
  - Root cause: Storing focal point at gesture start instead of using live values
  - Removed focalX/focalY shared values completely
  - Now uses e.focalX/e.focalY directly in each onUpdate call
  - Converts focal to world coordinates using transform at gesture start
  - Keeps the world point consistently under the fingers as scale changes
  - Fixed Skia transform order to scale first, then translate
  - Changed gesture composition from Simultaneous to Race with pan yielding to pinch
  - Added DPR constant (set to 1 for DIP-aligned Skia)
  - Result: Smooth, stable zoom on both simulator and physical devices

#### Admin Edit Mode - Phase 2: Visual Identity (2025-09-04)

- ✅ Created PhotoEditor component with premium iOS-style interface
  - Circular photo preview (160x160) with glass morphism card
  - URL input field with live preview (800ms debounce)
  - Loading spinner overlay during image fetch
  - Error state with icon and message for invalid URLs
  - "Remove Photo" button with gradient style and confirmation dialog
  - Smooth animations and haptic feedback
  - URL validation (requires https:// or http://)
- ✅ Integrated PhotoEditor into ProfileSheet
  - Replaces static hero image in edit mode
  - Maintains existing photo display in view mode
  - Proper data flow through editedData state
  - Seamless save functionality with backend

### 🚧 In Progress

#### Admin Edit Mode - Remaining Phases

- Phase 3: Smart Date Editing - Hijri/Gregorian date pickers
- Phase 4: Relationship Selector - Parent selection UI
- Phase 5: Advanced Controls - Admin-only fields
- Phase 6: Marriage Management - Add/edit/delete marriages UI

### 📋 TODO

#### High Priority Features to Implement

1. **Marriage Management UI**
   - Deploy admin_create_marriage function to production
   - Create MarriageEditor component
   - Add spouse selector with smart filtering
   - Implement marriage CRUD operations in admin mode

2. **Fix Missing Backend Functions**
   - Either implement get_person_with_relations RPC or remove from service layer
   - Consider if aggregating relations would improve performance

3. Admin Features
   - Batch operations UI
   - Change history viewer
   - Field templates
   - Offline support with sync

4. Performance Optimizations
   - Viewport-based node loading
   - WebGL rendering for large trees
   - Background data prefetching

5. Enhanced Features
   - AI-powered relationship suggestions
   - Smart data validation
   - Automated backups
   - Export functionality

## Version History

### v1.0.0 - Initial Release

- Core tree visualization
- Basic profile viewing
- Admin authentication

### v1.1.0 - Edit Mode Phase 1

- ✅ Editable name, bio, and sibling order fields
- ✅ World-class iOS-native UI/UX
- ✅ Premium glass design system

### v1.2.0 - Photo Upload System (COMPLETED)

- ✅ Native photo upload with camera/gallery picker
- ✅ Supabase storage integration
- ✅ Client-side image optimization
- ✅ EXIF metadata stripping for privacy
- ✅ Progressive loading with retry mechanism
- ✅ Fixed image display issues in ProfileSheet

### v1.3.0 - Photo System Improvements Phase 1 (COMPLETED)

- ✅ Implemented expo-image for native caching
- ✅ Created unified CachedImage component
- ✅ Added image cache service with size management
- ✅ Unified loading states with shimmer effect
- ✅ Image preloading for visible nodes
- ✅ Fallback system for Supabase transformations

### v1.3.1 - LOD System Improvements (COMPLETED)

- ✅ Fixed LOD tier switching timing
- ✅ Removed double-scaling issues with PixelRatio
- ✅ Added dynamic zoom-to-fit for viewing entire tree
- ✅ Improved Tier 2 pill visibility and readability
- ✅ Force Tier 3 aggregation when appropriate
