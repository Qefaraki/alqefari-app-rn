# LOD Fixes Summary - January 2025

## Overview

Fixed LOD (Level of Detail) system issues where LOD wasn't activating early enough and the tree didn't fit on screen.

## Issues Fixed

### 1. Wrong Units in Tier Math

- **Problem**: PixelRatio.get() was inflating node sizes in LOD calculations
- **Fix**: Removed PixelRatio.get() from calculateLODTier - now uses `nodeScreenPx = NODE_WIDTH_WITH_PHOTO * scale`
- **Location**: TreeView.js line 391

### 2. Image Bucket Selection

- **Problem**: PixelRatio.get() causing images to persist too long
- **Fix**: Fixed ImageNode pixelSize calculation to use `width * scale` only
- **Location**: TreeView.js line 184

### 3. Min Zoom Too Tight

- **Problem**: Hardcoded minZoom=0.15 prevented viewing entire tree
- **Fix**: Added dynamic fitScale and localMinZoom calculations
- **Code**:

  ```javascript
  const fitScale = useMemo(() => {
    const dx = maxX - minX + 800;
    const dy = maxY - minY + 800;
    const screenWidth = dimensions.width;
    const screenHeight = dimensions.height;
    return Math.min(screenWidth / dx, screenHeight / dy) * 0.85; // 85% to add margin
  }, [maxX, minX, maxY, minY, dimensions]);

  const localMinZoom = Math.min(minZoom, fitScale);
  ```

- **Location**: TreeView.js lines 781-812

### 4. Updated LOD Thresholds

- **Changes**:
  - T1_BASE: 48 → 140 (drop photos earlier)
  - T2_BASE: 24 → 80 (pills → chips earlier)
  - MAX_VISIBLE_EDGES: 300 → 200 (better performance)
- **Location**: TreeView.js lines 48-53

### 5. Force Tier 3 Aggregation

- **Problem**: Tier 3 not activating until very end
- **Fix**: Added forceTier3 logic when near fit scale or overloaded
- **Code**:
  ```javascript
  const forceTier3 =
    currentScale <= fitScale * 1.5 || visibleNodes.length > MAX_VISIBLE_NODES * 0.7;
  ```
- **Location**: TreeView.js lines 1870-1872

### 6. Tier 2 Pill Visibility

- **Problem**: Pills too small and unreadable
- **Fixes**:
  - Added PILL_MIN_W = 56 for minimum width
  - Updated nodeWidth calculation: `Math.max(60, PILL_MIN_W)`
  - Added scaled fontSize: `Math.max(10, 10 * (node._scale || 1))`
- **Location**: TreeView.js lines 1529-1577

### 7. Pinch Gesture Updates

- **Change**: Updated to use localMinZoom instead of hardcoded minZoom
- **Code**: `const s = clamp(savedScale.value * e.scale, localMinZoom, maxZoom);`
- **Location**: TreeView.js line 1077

### 8. Zoom-to-Fit Feature

- **Added**: zoomToFit function that animates to fitScale
- **Code**:
  ```javascript
  const zoomToFit = useCallback(() => {
    scale.value = withSpring(fitScale);
    translateX.value = withSpring(-(maxX + minX) / 2);
    translateY.value = withSpring(-(maxY + minY) / 2);
  }, [fitScale, maxX, minX, maxY, minY]);
  ```
- **Location**: TreeView.js lines 802-810

## Testing Checklist

- [ ] Zoom out fully - should see only 3 aggregated chips
- [ ] Mid zoom - should see text pills without images
- [ ] Close zoom - should see full cards with photos
- [ ] Entire tree fits on screen at minimum zoom
- [ ] LOD transitions happen earlier than before
- [ ] No jumping between tiers (hysteresis working)
- [ ] Tier 2 pills are readable with minimum width

## Impact

These fixes ensure the LOD system activates at appropriate zoom levels, the entire tree is viewable, and performance remains optimal even with large family trees.
